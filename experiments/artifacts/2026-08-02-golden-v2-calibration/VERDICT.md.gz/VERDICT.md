# Wave 1 Q1 — calibration diagnosis (2026-08-02)

Question (GOLDEN-DATASET-V2-SPEC.md, 8d6f04b): is the one-tier gap between
the cross-task two-judge pools and golden-v1 on the three exporter blockers
a rubric effect (the pool prompt lacked the RULINGS) or a deliberation
effect?

Method: the frozen exporter pool's full 28-candidate batch re-judged with
the three RULINGS (post RULING-3 fold, 18b5627) inserted into the pool
judge prompt — the ONLY change against the frozen run (base prompt sha
`aa289b82…`, rulings prompt sha `421c5f38…`; guard asserted the prompts
differ by exactly the RULINGS block). Same judges (gpt-5.6-sol high via pi,
opus high via claude -p), independent labels, no deliberation, no retries
needed. Verdict read from the four rows stating the three golden issues:
`s01`→EXP-offset-drift, `g01`→EXP-c-12, `g07`/`g26`→EXP-c-11 (one
defective expression, two pool wordings).

## Result: 0 of 3 flipped — the pre-registered "deliberation is load-bearing" reading fires

| golden issue | pool row | frozen run (sol/opus) | with RULINGS (sol/opus) |
|---|---|---|---|
| EXP-offset-drift | s01 | serious / serious | serious / serious |
| EXP-c-12 | g01 | serious / serious | serious / serious |
| EXP-c-11 | g07 | serious / serious | serious / serious |
| EXP-c-11 | g26 | serious / serious | serious / serious |

The RULINGS were demonstrably read: sol's g26 reason opens "In the earlier
exporter state…" (RULING 3 applied), and 3 of the 11 rows that moved
elsewhere in the batch are docs-state claims (g16, g17, g24) — exactly
where the temporal frame bites. The rulings changed judgments where they
speak, and the serious/blocking boundary is not where they speak.

## Anomaly pass (raw rows, before this verdict)

- Zero of 56 judgments say `blocking`, before or after — the boundary
  never moved anywhere in the batch, both directions.
- 11/28 rows moved, all inside none↔minor↔serious; sol drifted upward on
  low-tier doc rows (consistent with RULING 3), opus moved on 4 rows.
  Ordinary bottom-of-scale wobble plus a real temporal-frame effect;
  triage: real-effect, no harness or label bug.
- Sharpened mechanism, found by reading the two rubrics side by side: the
  pool probe's HARM_ANCHORS put "a silent failure that will bite in normal
  operation" under **serious**, while the consensus RUBRIC enumerates
  "silent incorrect results" under **blocking**. All three drifted issues
  are silent-failure mechanisms. The instruments DEFINE the boundary
  differently — a conventions block that never touches the boundary
  definition cannot close a definitional gap. "Deliberation is
  load-bearing" stands as the pre-registered reading; the definitional
  difference is the surviving candidate mechanism for WHY, and aligning
  HARM_ANCHORS with the consensus blocking enumeration is a registered
  follow-up factor test, not something to patch in after seeing the data.

## Protocol rule (effective now, per the pre-registered reading)

1. An issue that matches an active golden record takes the GOLDEN tier by
   definition; pool tiers never override it.
2. Pool tiers are ADVISORY. Any tier that enters a decision table comes
   from golden matching or from the full three-participant deliberated
   protocol. Two-judge independent pool labels remain what they were
   measured to be: a coverage/precision instrument, not a tiering one.

Judgments: `calibration-judgments.json` (full before/after batch, reasons,
prompt hashes). Subscription-billed, $0 metered, no producer spend.
