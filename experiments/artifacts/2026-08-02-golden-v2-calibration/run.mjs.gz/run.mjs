#!/usr/bin/env node
/**
 * GOLDEN-DATASET-V2-SPEC Wave 1 Q1 — calibration diagnosis.
 *
 * Re-judges the cross-task exporter pool with ONE factor varied: the three
 * RULINGS (golden-dataset-consensus.mjs, post RULING-3 fold, commit 18b5627)
 * inserted into the pool-probe judge prompt. Same 28 candidates in the same
 * order, same code context derived from the same frozen rows, same judge
 * models at the same efforts, independent labels, no deliberation. The full
 * batch is re-judged so batch composition stays identical; the verdict is
 * read from the four rows that state the three golden-drifted issues:
 *
 *   EXP-offset-drift -> s01 (the seeded planted statement)
 *   EXP-c-12         -> g01 (csvField quote-class omits CR)
 *   EXP-c-11         -> g07 OR g26 (same defective expression under
 *                       RULING 2: Number(options.limit) unvalidated; the
 *                       run pool kept two wordings)
 *
 * Pre-registered readings (GOLDEN-DATASET-V2-SPEC.md, 8d6f04b): >=2 of the 3
 * golden issues unanimous-blocking -> rubric effect; <=1 -> deliberation is
 * load-bearing.
 */

import { readFileSync, writeFileSync } from "node:fs";
import { gunzipSync } from "node:zlib";
import { createHash } from "node:crypto";

const REPO = "/Users/spannagel/dev/personal/pi-hydra.piped-discovering-minsky";
const ART = `${REPO}/experiments/artifacts/2026-08-02-cross-task-trajectory`;
const OUT = "/Users/spannagel/scratch/2026-08-02-golden-v2/calibration";

const { judgePrompt, parseJudgments, piTransport, claudeCliTransport, askWithRecovery, codeContext } =
	await import(`${REPO}/experiments/severity-pool-probe-v2.mjs`);
const { RULINGS } = await import(`${REPO}/experiments/golden-dataset-consensus.mjs`);

const sha = (text) => createHash("sha256").update(text).digest("hex");
const gunzip = (path) => gunzipSync(readFileSync(path)).toString("utf8");

const sev = JSON.parse(gunzip(`${ART}/severity-exporter.json.gz`));
const rows = gunzip(`${ART}/rows-exporter.jsonl.gz`).trim().split("\n").filter(Boolean).map((line) => JSON.parse(line));

const candidates = sev.candidates;
if (candidates.length !== 28) throw new Error(`expected 28 candidates, got ${candidates.length}`);
const code = codeContext(rows);

const basePrompt = judgePrompt(candidates, code);
const prompt = judgePrompt(candidates, code, RULINGS);
if (!RULINGS.startsWith("THREE BINDING CONVENTIONS")) throw new Error("RULINGS is not the three-convention text");
if (prompt.replace(`${RULINGS}\n\n`, "") !== basePrompt) throw new Error("prompt differs from base by more than the RULINGS block");

const TARGETS = [
	{ golden: "EXP-offset-drift", pool: ["s01"] },
	{ golden: "EXP-c-12", pool: ["g01"] },
	{ golden: "EXP-c-11", pool: ["g07", "g26"] },
];

console.log(`base prompt sha256 ${sha(basePrompt).slice(0, 16)}, rulings prompt sha256 ${sha(prompt).slice(0, 16)}`);
console.log("asking sol + opus (independent, no deliberation)...");

const sol = await piTransport({ provider: "openai-codex", model: "gpt-5.6-sol", reasoning: "high" });
const opus = claudeCliTransport({ model: "opus", reasoning: "high" }, 900000);
const [solJ, opusJ] = await Promise.all([
	askWithRecovery(sol, prompt, (text) => parseJudgments(text, candidates.length)),
	askWithRecovery(opus, prompt, (text) => parseJudgments(text, candidates.length)),
]);

const index = new Map(candidates.map((candidate, i) => [candidate.id, i]));
const record = (id) => {
	const i = index.get(id);
	return {
		pool: id,
		statement: candidates[i].statement,
		before: { sol: sev.judgments.sol[i].harmIfExecuted, opus: sev.judgments.opus[i].harmIfExecuted },
		after: {
			sol: solJ.parsed[i].harmIfExecuted,
			opus: opusJ.parsed[i].harmIfExecuted,
			solReason: solJ.parsed[i].reasoning,
			opusReason: opusJ.parsed[i].reasoning,
		},
	};
};

const targets = TARGETS.map((target) => {
	const members = target.pool.map(record);
	const unanimousBlocking = members.some((m) => m.after.sol === "blocking" && m.after.opus === "blocking");
	return { golden: target.golden, unanimousBlocking, members };
});

const flipped = targets.filter((t) => t.unanimousBlocking).length;
const reading = flipped >= 2 ? "RUBRIC EFFECT (>=2 of 3 unanimous-blocking)" : "DELIBERATION LOAD-BEARING (<=1 flipped)";

for (const t of targets) {
	for (const m of t.members) {
		console.log(`${t.golden} [${m.pool}] before sol=${m.before.sol}/opus=${m.before.opus} -> after sol=${m.after.sol}/opus=${m.after.opus}`);
		console.log(`   sol: ${m.after.solReason}`);
		console.log(`   opus: ${m.after.opusReason}`);
	}
}
console.log(`\nVERDICT INPUT: ${flipped}/3 golden issues unanimous-blocking -> ${reading}`);

writeFileSync(`${OUT}/calibration-judgments.json`, JSON.stringify({
	runId: "2026-08-02-golden-v2-calibration",
	spec: "GOLDEN-DATASET-V2-SPEC.md wave 1 Q1 (8d6f04b)",
	rubricCommit: "18b5627",
	basis: {
		artifact: "experiments/artifacts/2026-08-02-cross-task-trajectory",
		candidateCount: candidates.length,
		basePromptSha256: sha(basePrompt),
		rulingsPromptSha256: sha(prompt),
		rulingsSha256: sha(RULINGS),
		judges: { sol: "gpt-5.6-sol high (pi)", opus: "opus high (claude -p)" },
		protocol: "independent labels, no deliberation, full 28-candidate batch re-judged; only the RULINGS block varies vs the frozen run",
	},
	targets,
	flipped,
	reading,
	recovered: { sol: solJ.recovered, opus: opusJ.recovered },
	full: {
		sol: solJ.parsed,
		opus: opusJ.parsed,
		before: { sol: sev.judgments.sol, opus: sev.judgments.opus },
		candidates: candidates.map((c) => ({ id: c.id, statement: c.statement })),
	},
}, null, 2));
console.log(`wrote ${OUT}/calibration-judgments.json`);
