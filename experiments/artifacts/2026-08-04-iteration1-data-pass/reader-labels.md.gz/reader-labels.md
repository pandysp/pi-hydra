All evidence verified. Writing findings.

**SURPRISE 5 — verdict: real-effect in the delivered bytes; the "2/15 vs 7/15 reversal" as a scoreboard statement does NOT survive.**

Per-blocker decomposition of ENUM-SO2 scheduler sol-high (consensus `2026-08-04-capstone-consensus/consensus-final.json.gz` + raw judge matches in `2026-08-03-openai-capstone-sol/judge-sol.json.gz` and `2026-08-04-openai-capstone-opus/judge-opus.json.gz`):

| blocker MAIN-SO2 got, ENUM-SO2 didn't | what actually happened |
|---|---|
| `SCHED-r-d05` + `SCHED-requeue-resets-attempts` | **raised outside credited form.** `r3/16` was the *only* r3 point where `attempts: 0` was still live (file-state: ATTEMPTS0 through pointIndex 16, ATTEMPTS-INC from 17). ENUM spent it on `"Add a boundary test for failures 1–5: attempts increment, first four requeue, and the fifth is removed from jobs and appears once in store.dead with lastError."` → both judges extracted one coverage claim → `SCHED-c-14` only. MAIN spent the same point on `"On failure, increment attempts first, test the incremented job against MAX_ATTEMPTS, and ensure an exhausted job is removed from store.jobs…"` → both blockers credited. |
| `SCHED-o-g07` | **raised outside credited form.** `…/a1/r3/21/ENUM-SO2/f2`: `"Dead-lettering directly deletes/pushes without coordinating pending saves… Make the move atomic in the store."` Sol matched `SCHED-r-d06` (harmful), Opus matched nothing. The owner-check assertion the catalog states is absent. |
| `SCHED-r-d14`, `SCHED-c-07` | **genuinely not raised.** No sol-high ENUM message touches complete-in-try or requeue-writes-stale-snapshot. Exposure was symmetric: `await complete(...)` sits inside the inner try at *every* point in both configs; `store.jobs.delete(job.id)` is live for exactly 5 points in each (sol-high 17–21, sol-xhigh 20–24). |

**Two blockers were lost in judging, and they run against the reported gap.** At `…/a1/r1/7/ENUM-SO2/f2` Opus matched `SCHED-r-d07` and `SCHED-r-d08` (both blocking); Sol matched only `SCHED-r-d06`/`SCHED-o-g14`. The registered intersection rule dropped them. Union would put ENUM-SO2 sol-high at **4/15, not 2/15**.

**The mechanism that is real, and is in the frozen bytes:** in the r3 window ENUM-SO2 sol-high emitted test-prescriptions at 4 of 6 points (r3/16,17,18,20 → all `SCHED-c-14`), with behavioral assertions only at r3/19 and the final r3/21. At sol-xhigh it paired a behavioral assertion *with* the test prescription at nearly every r3 point — `SCHED-o-g07` asserted 5×(r3/20–24), `SCHED-r-d14` 4×(r3/21–24). Same window length, same exposure, opposite content mix.

**Why it can't be called an effort-dependent reversal:** n=1 trajectory per cell, and 2 of the 5-blocker gap turn on a single message at a single point (r3/16). Sol-high and sol-xhigh are also *different driver trajectories* (22 vs 25 points; r1 doc-window 3 vs 6 points) because effort moves driver and observer together. Reporting this as a stable arm×effort interaction would mislead iteration 2.

**SURPRISE 6 — verdict: harness-bug (comparison-level). The precision gap is entirely the eligibility-policy change, not SO2 wording.**

The two packets have structurally different judgeable point sets. `experiments/capstone-trajectory-judge-protocol.mjs:56` — `const semantic = eligibilityPolicy === "semantic-v2";` and line 26 drops `row.valid === false` unless semantic. Fresh basis carries `"eligibilityPolicy": "semantic-v2"`; the old packet basis has **no such key** (default `strict-v1`). Byte-level reconstruction from the raw rows:

- fresh under semantic-v2 → **264 findings, exactly the packet count**; under strict-v1 → 244.
- old under strict-v1 → 119; packet has 107. The 12-finding diff is exactly the final `run-end` point of each cell (`scheduler/sol-high/a1/r3/19`, `scheduler/sol-xhigh/a1/r3/18`) — the old artifact needed `recoverRunEndAssistant` and fails closed on a cell's last run.

Fresh MAIN-SO2 scheduler sol-high raised 17; **4 come from cache-only-invalid rows and 0 of the 4 are real.** Those rows are invalid on a *cost* assertion only — e.g. `r0/1`: `assertionFailures: ["cacheRead 2560 below 0.8 x prefix 3326 — the observation is not riding the driver's cache"]`. Under strict-v1 they would not exist.

| alignment | fresh MAIN-SO2 sol-high | old MAIN sol-high |
|---|---|---|
| as scored | 11/17 = 64.7% | 9/11 = 81.8% |
| valid-source only | **11/13 = 84.6%** | 9/11 = 81.8% |
| valid-source, final point dropped | **10/12 = 83.3%** | 9/11 = 81.8% |

The gap vanishes — reverses slightly — under every alignment. And the point rule *depressed* old MAIN if anything: its dropped `r3/19` finding (`"Add tests for stats expiry counts, runOnce summaries, attempt increments, fifth-failure removal from jobs, and insertion into store.dead."`) is textually the same shape as its `r3/17` finding, which was credited `SCHED-c-14`+`SCHED-r-d32`.

**Same failure modes, no new ones from SO2 wording.** Both valid-source non-credits in fresh MAIN-SO2 (`r2/10`, `r2/11`) and both in old MAIN (`r1/9`, `r2/11`) are the identical mode: Opus returned zero claims for the whole batch. The 4 extra are a new *category* admitted by the policy, not a new defect in the arm's output. Honest second half: the policy lands on MAIN-SO2 sol-high specifically because that arm steered on all 4 cache-invalid warm-up points while ENUM-SO2 steered on 2. Both halves are in the bytes.

**Two secondary findings, same columns, not on the surprise list**

1. **Opus one-sided zero-claim batches — 17 of 109 fresh batches, 27 findings, all auto-not-real.** Opus returned empty claims for an entire batch where Sol extracted claims 17 times; the reverse happened **0 times**. All 17 are well-formed model decisions, not transport damage: `recovered: false`, `firstResponse == finalResponse`, ids exactly `j01…jNN`, every `claims: []` (e.g. `{"findings":[{"id":"j01","claims":[]},{"id":"j02","claims":[]}]}` at `scheduler/sol-high/a1/r2/10`, whose Sol side carried 4 supported claims, 2 matching `SCHED-r-d32`). This is a systemic precision suppressor that hits arms unevenly by which points they steer at.

2. **The precision column is in different units per arm.** MAIN-SO2 emits one `{action,reason,message}` object per delivery (`decision.findings` is `None`), so `raised` = steer count; ENUM-SO2 emits `{"findings":[…]}`, so `raised` = enumerated items. MAIN-SO2 `…/a1/r1/7/f0` carried three credited catalog ids in **one** raised finding; ENUM needs three findings for the same, each separately at risk. The metric structurally favors the prose arm across the whole table.

**Consequence for the results doc:** the "Generations" bullet ("the steer-only collapse did not damage ENUM's recall") is not supportable from these two packets. Old ENUM sol-high's dropped `r3/19` f0 reads `"requeue() never verifies the stored owner. Concurrent claimers can let a stale failure delete a newer claim into store.dead. Re-read the job and require claimedBy to match before requeueing or dead-lettering."` — textually the `SCHED-o-g07` assertion, and `SCHED-o-g07` is a blocking id old ENUM sol-high did not receive. Old-generation blocking counts are depressed by an unknown non-zero amount.

**Additional non-comparability not decomposed:** the two packets were also built with different judge prompt builders (`judgeBuilderHash` old `df3cc0f57a725965` vs fresh `5880bf010bbb428e`). The eligibility difference fully accounts for the finding-set difference; the builder difference means the judges also saw differently-constructed prompts, and that residual is unmeasured.

Working files: `/Users/spannagel/scratch/2026-08-04-lookdata-s56/` (decompressed frozen inputs, `enum-solhigh-findings.txt`). Nothing in the repo was modified.