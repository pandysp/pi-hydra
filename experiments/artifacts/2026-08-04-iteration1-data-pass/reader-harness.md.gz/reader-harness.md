# Look-at-the-data pass, iteration 1 — surprises 1, 2, 7 (harness side)

Nothing in the repo was changed. All numbers recomputed from the frozen inputs; probe scripts live in `/tmp` only.

## Verdicts

| # | Verdict | One line |
|---|---|---|
| 1 | **harness-bug** (confirmed) — plus a **second, unrecorded harness-bug** in the same module | `payloadChunks` reads `payload.messages`; the Responses payloads have `input`. Zero chunks on all 131 payloads. The window-*close* rule additionally fires on grep output — latent until now because the walker never ran on real data. |
| 1 (quiet spans) | **no-issue** on the recording; **documentation defect** on the stated reason | Column correctly reads 0, footnote correctly flags vacuity, no verdict leans on it. The reason given ("live from point 0") is incomplete, and the loss is larger than "vacuous" implies. |
| 2 | **harness-bug** (renderer diverges from registered text); iteration-1 handling protocol-correct | Table reported `raised − real`. All 18 cells differ from the registered count. Both numbers were published, so nothing needs retraction. |
| 7 | **real-effect** — the policy is *not* arm-neutral | It systematically disadvantages MAIN-SO2, and it is the dominant explanation for surprise 6. |

---

## (a) Surprise 1 — payload-liveness walker

### Root cause, one line

`/Users/spannagel/dev/personal/pi-hydra.piped-discovering-minsky/experiments/trajectory-ground-truth.mjs:121`

```js
for (const [messageIndex, message] of (payload?.messages ?? []).entries()) {
```

Capstone payloads are OpenAI Responses requests. Top-level keys: `model, store, stream, instructions, input, text, include, prompt_cache_key, tool_choice, parallel_tool_calls, tools, reasoning`. No `messages`. `payloadChunks` returns `[]`; `defectStateInPayload` returns `null` unconditionally.

### Measured over all 131 frozen payloads

Source: `experiments/artifacts/2026-08-03-openai-capstone-producer/payloads.tar.gz`, sha256 `401c38dfdfd6845ceef5e28a4f1519246c65ee3845fcc07818e9ca1406be4ae7` (the registered hash in `CAPSTONE-JUDGE-SPEC.md`), extracted to `/tmp/capstone-frozen/payloads`.

- payloads carrying a `messages` key: **0 / 131**
- total chunks returned by `payloadChunks()` across all 131: **0**
- non-null `defectStateInPayload` results across 131 payloads × all task defects: **0**
- payloads whose raw bytes contain ≥1 defective expression: **92 / 131**

**Not a path/IO problem — the fix is localized entirely to the walker.** `capturedPayloadPath` points at `/Users/spannagel/scratch/2026-08-03-openai-capstone/payloads/`; that directory exists with 131 files, byte-identical to the frozen tarball (`cmp`, 131/131). 107/131 reproduce their row's `capturedPayloadHash` exactly (`sha256(bytes)[0:16]`, per `trajectory-cost-ab.mjs:861`); the 24 that don't are the per-run first request (`q0`), which carries no observation point.

### Three reproductions — the bytes the walker misses

**1. `function_call_output` (tool read-back → must be authoritative)**
`dispatcher-sol-high-a1-r1-q10.json`, sha256[0:16] `163ee02e8f34cb75` (= row `capturedPayloadHash`), `input[53].output`:

```
…\t\treturn post(client, "/v1/charges", {\n\t\t\torder: charge.orderId,…
```

matches `retry-no-idempotency-key` expression `/post\(client, "\/v1\/charges", \{/`. `payloadChunks` → 0.

**2. `function_call` name=`edit`, `arguments` is a JSON *string* (the trap)**
`dispatcher-sol-high-a1-r2-q16.json`, sha256[0:16] `65bdb33d0c9c61aa`, `input[85].arguments`. Parsed → `{path:"src/retry.js", edits:[{oldText,newText}]}`; **both** texts carry

```
\treturn { ok: true, attempts, response: null, note: lastError?.message ?? "exhausted" };
```

= `retry-swallowed-failure`. Not a fix; the edit reshapes the signature only. In the Anthropic path `block.input` was already an object — here `arguments` is a string, and `normalizeEditInput()` sees nothing until it is `JSON.parse`d. `payloadChunks` → 0.

**3. The one genuine payload-visible FIX in the corpus — this is what decides authoritative classification**
`scheduler-sol-high-a1-r3-q18.json`, sha256[0:16] `296585fbe65ec7cc`, `input[108]` (edit, `src/worker.js`):

```
oldText: …const next = { ...job, state: "pending", claimedBy: null, attempts: 0, lastError: error.message };…
newText: …\t\tattempts: job.attempts + 1,\n\t\tlastError: error.message,…
```

`sched-requeue-resets-attempts`, expression `/attempts: 0, lastError/`, present in `oldText` **only**. A fix that treats `arguments` wholesale as authoritative marks this defect live at the exact point it was repaired — the "every fix looks like a re-plant" failure the module header (lines 85–99) exists to prevent. 8 of the 80 expression×edit hits in the corpus are oldText-only; all 8 are `sched-requeue-resets-attempts`.

### What an iteration-2 fix must parse

Over `payload.input[]`, plus a decision on top-level `instructions`:

- **`{role, content:[…]}` items with NO `type` field**, AND **`{type:"message", role, content:[…]}`** — both shapes occur. Text blocks of type `input_text` | `output_text` | `text` → **authoritative**. Dispatching only on `item.type` silently drops the bare-role shape.
- **`{type:"function_call", name, arguments}`** — `arguments` is a JSON **string**; `JSON.parse` first.
  - `name === "write"` && parsed `.content` is a string → authoritative (`write`).
  - `name === "edit"` → `normalizeEditInput(parsed)` → `newText` **authoritative**, `oldText` **non-authoritative** (semantics unchanged).
  - any other tool → non-authoritative `tool-args`.
- **`{type:"function_call_output", output}`** → **authoritative**. `output` is a plain string on this corpus; handle array-of-parts defensively.
- **`{type:"reasoning", encrypted_content, content:[]}`** → skip. No plaintext exists on this corpus; skipping is correct, not residual blindness.
- **top-level `instructions`** → **moot on this data**: 0 of 131 payloads matches any defect expression there. Decide it explicitly rather than by omission.

**Reuse, do not reinvent:** `visiblePayload()` at `/Users/spannagel/dev/personal/pi-hydra.piped-discovering-minsky/experiments/capstone-trajectory-judge-protocol.mjs:84-102` already walks exactly this shape (instructions / role+content with `input_text|output_text|text` / `function_call` / `function_call_output`), is frozen, and was exercised on these exact payloads by both judge columns. The iteration-2 walker is that traversal + the authoritative classification + the `arguments` parse.

Where expressions actually land across all 131 payloads: `function_call_output.output` (631 defect×item hits) and `function_call(edit).arguments` (80). Nowhere else.

### Quiet-span vacuousness — correctly documented, incomplete reason, larger loss

**Correct:** the column recorded 0 by construction in all 18 rows; `CAPSTONE-SCORING-RESULTS.md:53-55` and `capstone-score.mjs:9-12` both say so, and no verdict sentence leans on it. Verdict: `no-issue` on the recording.

**Incomplete reason.** Line 102–103 says "every cell's span set is empty (planted defects live from point 0)". Under `capstone-score.mjs:91-98` a point is quiet iff **zero** planted defects are live on disk — live-from-point-0 explains only why point 0 is not quiet, not why no *later* point is. Recomputed from the frozen `file-state` rows:

| cell | points | live-per-point | MIN |
|---|---|---|---|
| scheduler/sol-high | 22 | 4×17, 3×5 | 3 |
| scheduler/sol-xhigh | 25 | 4×20, 3×5 | 3 |
| exporter/sol-high | 16 | 3×16 | 3 |
| exporter/sol-xhigh | 19 | 3×19 | 3 |
| dispatcher/sol-high | 25 | 3×25 | 3 |
| dispatcher/sol-xhigh | 23 | 3×23 | 3 |
| old scheduler/sol-high | 20 | 4×16, 3×4 | 3 |
| old scheduler/sol-xhigh | 19 | 4×15, 3×4 | 3 |

Exactly one plant is ever fixed on disk anywhere in the corpus (`sched-requeue-resets-attempts`, at point index 17/20/16/15 in the four scheduler cells). No cell is one fix away from a span; every cell is three.

**The larger point.** The files substitution is *structurally incapable* of finding the span the corpus was built around. `trajectory-cost-tasks.mjs` header: "One quiet stretch per trajectory … prompt 1 is scoped to two small defect-free files, so the whole first run is observed before any defective expression has ever entered the payload." That stretch is quiet in the **payload** sense only; on disk the plants are present from point 0 by construction. So the column is not "vacuous, nothing lost" — the substitution deleted precisely the designed signal.

**Iteration-2 prediction** (probe only, repo unchanged). Opening spans (`points 0..firstVisible−1`) depend only on the precise expression regex, so they are sound:

| cell | opening quiet span | MAIN-SO2 deliveries | ENUM-SO2 deliveries |
|---|---|---|---|
| scheduler/sol-high | 0–3 (4 pts, run 0) | 3 | 1 |
| scheduler/sol-xhigh | 0–2 (3) | 1 | 1 |
| exporter/sol-high | 0–4 (5) | 2 | 3 |
| exporter/sol-xhigh | 0–4 (5) | 1 | 1 |
| dispatcher/sol-high | 0–7 (8) | 6 | 5 |
| dispatcher/sol-xhigh | 0–0 (1) | 1 | 0 |

A column that read 0 in every cell should read **at least 14 (MAIN-SO2) / 11 (ENUM-SO2)** once the walker is fixed.

**Corpus note:** dispatcher/sol-xhigh falsifies the "whole first run is quiet" design claim. `retry-no-idempotency-key` becomes payload-live at run-0 point 1 via a `grep -C` output that printed the defective body — `dispatcher-sol-xhigh-a1-r0-q2.json` (sha `5fa0cf085b3fe209`) `input[11]`: `src/dispatch.js-12- \t\treturn post(client, "/v1/charges", {`. Legitimate sighting; the design assumption is what is wrong.

### Second harness bug, not on the surprise list — window-close fires on grep output

- dispatcher/sol-high point 14 → `dispatcher-sol-high-a1-r2-q15.json` `input[79]` (tool-result). Deciding "fixed" chunk is a grep hit line showing the declaration with none of the body:
  `src/retry.js:12: export async function withRetries(operation, { attempts = MAX_ATTEMPTS, sleep = defaultSleep } = {}) {`
  — while disk state at that point is `live` and stays live to the end of the cell.
- Same at scheduler/sol-xhigh point 10 → `scheduler-sol-xhigh-a1-r1-q11.json` `input[60]`: `src/scheduler.js:10: export async function claimNext(store, worker) {`.

This is in the **original** walker too (an Anthropic grep `tool_result` closes identically). What makes it newly load-bearing: it was latent because `defectStateInPayload` had never run on real data before this corpus — old bug, first exposure. It must land in the **same** iteration-2 pass, or the repaired walker manufactures spans: my probe's close-derived spans (dispatcher/sol-high 14–24, scheduler/sol-xhigh 20–24) are entirely artifacts of it. Fix direction: require the closing chunk to show the declaration together with a body region, or bar grep results from closing while still letting them open (an expression sighting in `grep -C` *is* real).

---

## (b) Surprise 2 — "absolute noise"

**What iteration 1 actually reported per cell: `raised − real`.**
`/Users/spannagel/dev/personal/pi-hydra.piped-discovering-minsky/experiments/render-capstone-table.mjs:19`

```js
const derivedNoise = row.precision.raised - row.precision.real;
```

emitted at line 27 as `noise: String(derivedNoise)`. `capstone-score.mjs:189` writes `precision: { real, raised }` onto the comparison row and never sets `absoluteNoise`.

**Registered text**, `BENCHMARK-SPEC.md:35-38`: "precision — raised issues judged real by both judges / raised issues; **the absolute both-judges-not-real count is reported beside it**".

The registered number *is* computed — `capstone-score.mjs:161-163` (`bothNotReal`) — but is written only to `details-*.json` (line 198, `bothJudgesNotReal`) and never reaches the renderer.

**Dead guard built for exactly this mismatch:** `render-capstone-table.mjs:20-22` throws when `row.absoluteNoise !== derivedNoise`. Never armed because the producer omits the field. That is where iteration 2 wires the fix.

**Would any cell differ? All 18 (12 fresh + 6 old). No cell is equal.**

```
fresh table (raised−real)   6 4 3 4 4 5 3 4 7 7 4 4
fresh details (bothNotReal) 3 1 1 1 2 4 1 2 2 2 1 1
old table                   2 3 5 1 1 3
old details                 1 1 2 0 0 2
```

Ranking impact: none on verdicts (noise is not a tie-break column per `BENCHMARK-SPEC:60-63`). Comparing the two published readings, two within-cell orderings move: fresh scheduler/sol-xhigh goes from MAIN quieter (3 vs 4) to tied (1 vs 1); old scheduler/sol-high goes from MAIN alone quietest (2 vs 3 vs 5) to MAIN/F2 tied (1 vs 1 vs 2).

**Third reading — the doc's quoted "stricter both-judges-not-real counts" are one low in two cells.** `bothNotReal` tests *absence of claim refs* from either judge. Claim refs are attached regardless of support: verified at `…/dispatcher/sol-high/a1/r1/13/MAIN-SO2/f0`, where Opus's claim carries `"centralSupported": false` yet still produces an `opusClaimRef`. The faithful reading of the spec sentence is "no claim from either judge has `centralSupported === true`". Computed from the raw judgment files it matches the code in 16 of 18 cells and is +1 in two:

- `exporter/sol-xhigh/ENUM-SO2` 2 → 3 (`…/exporter/sol-xhigh/a1/r1/9/ENUM-SO2/f0` — both judges refute the premise)
- `dispatcher/sol-high/ENUM-SO2` 2 → 3 (`…/dispatcher/sol-high/a1/r1/11/ENUM-SO2/f0` — Sol `centralSupported=false`, Opus no claim)

Correct these alongside the renderer in the versioned follow-up.

---

## (c) Surprise 7 — cache-only-invalid policy

### Every cache-only-invalid point, fresh input

31 distinct points, 47 observations. **All 47 invalid observations in the fresh input are cache-only-invalid** — no other invalidity exists.

**MAIN-SO2 (26 observations)**
```
scheduler/sol-high    r0/0 r0/1 r0/2 r0/3 r0/4 r0/6
scheduler/sol-xhigh   r0/0 r0/1 r0/2
exporter/sol-high     r0/0 r0/1 r0/2 r0/3 r0/4 r1/8
exporter/sol-xhigh    r0/0 r0/2 r0/3 r0/4 r1/9
dispatcher/sol-high   r0/0 r0/1 r0/2
dispatcher/sol-xhigh  r0/0 r0/3 r0/4
```
**ENUM-SO2 (21 observations)**
```
scheduler/sol-high    r0/1 r0/2 r1/9
scheduler/sol-xhigh   r0/1 r0/2
exporter/sol-high     r0/0 r0/1 r0/2 r0/3 r0/4 r1/6
exporter/sol-xhigh    r0/0 r0/1 r0/2 r0/3 r0/4 r1/8
dispatcher/sol-high   r0/0 r0/2 r0/3
dispatcher/sol-xhigh  r0/0
```

16 points invalid for **both** arms; 15 for one arm only. 27 of 31 are in run 0 (cache-cold start); exceptions exporter `r1/6`, `r1/8`, `r1/9` and scheduler `r1/9`.

### Point-level incidence is not arm-biased

- MAIN-SO2 26/130 vs ENUM-SO2 21/130 (Fisher p = 0.52)
- by slot: `armOrderIndex` 0 → 25/130, `armOrderIndex` 1 → 22/130
- MAIN@order0 16/66 vs ENUM@order0 9/64 (p = 0.18)

One-arm-only invalidity leans to whoever ran first (MAIN@order0 7, ENUM@order0 2, MAIN@order1 3, ENUM@order1 3), consistent with the first observer at a point going cache-cold. Not significant, and not the mechanism that matters.

### Finding level is where it bites

- 23 of the 264 fresh findings come from cache-only-invalid points: **MAIN-SO2 14, ENUM-SO2 9**.
- As a share of each arm's raised set: **MAIN 14/95 = 14.7% vs ENUM 9/169 = 5.3%** (Fisher p = 0.012).
- Only **5 of the 23 are credited** (MAIN 3, ENUM 2). 18 are pure precision drag.
- Adapter arithmetic closes: strict-v1 244 + 23 cache-only-invalid − 3 dropped at the failed-driver checkpoint (`dispatcher/sol-xhigh` r2/18, driver-turn error `"WebSocket error"`) = **264**.

**Mechanism, reproduced from the raw judge files** (`experiments/artifacts/2026-08-04-openai-capstone-opus/judgments-opus.jsonl.gz`, `…-sol/judgments-sol.jsonl.gz`), not from the consensus notes:

| judge | zero claims on cache-only-invalid | zero claims on valid |
|---|---|---|
| Opus | 18/23 (78%) | 31/241 (13%) |
| Sol | 11/23 (48%) | 10/241 (4%) |

Credit requires both judges, so a cache-only-invalid finding is near-uncreditable by construction.

**Counterfactual precision (drop the 23, i.e. strict-v1):**

| arm | sched-high | sched-xhigh | exp-high | exp-xhigh | disp-high | disp-xhigh | mean Δ |
|---|---|---|---|---|---|---|---|
| MAIN-SO2 | 64.7→84.6 | 83.3→88.2 | 50.0→66.7 | 75.0→80.0 | 66.7→68.4 | 78.9→87.5 | **+9.5 pts** |
| ENUM-SO2 | 84.0→87.0 | 90.2→92.5 | 64.3→81.8 | 75.0→80.0 | 81.6→83.3 | 88.6→88.6 | **+4.9 pts** |

**Why asymmetric when incidence is not:** the policy admits a similar *absolute* number of near-uncreditable findings to each arm (14 vs 9), but precision is a ratio and MAIN-SO2's raised denominator is 56% of ENUM-SO2's (95 vs 169). The low-volume arm pays roughly twice the precision tax for the same policy. Structural — not arm-specific cache behaviour — and it will recur in every future run pairing a terse arm with a verbose one under semantic-v2.

### Surprise 6 is resolved by this

The fresh-vs-old MAIN precision gap is an **eligibility-policy artifact, not an SO2 wording effect**. The old input ran strict-v1 (`CAPSTONE-JUDGE-SPEC.md`: "the earlier Sol artifact remains on strict-v1"). Measured: `buildFindingItems` on the old rows gives **119 under strict-v1 vs 131 under semantic-v2**, and of the 12 excluded only **1** belonged to sol-high MAIN (ENUM 2 + 8, F2 0, MAIN 1 + 1). Put both generations on the same policy and the gap does not merely close, it **reverses**: fresh MAIN-SO2 scheduler sol-high **11/13 = 84.6%** vs old MAIN **9/11 = 81.8%**.

### Four examples read in full

1. `scheduler/sol-high/a1/r0/1` MAIN-SO2 f0 — *"Test pluralize for 1, default plural, and an explicit irregular plural; only change implementation if an asserted case fails, then run the tests."* Consensus: 0 defects; notes *"Cache-only-invalid source; the message is purely prescriptive test advice and neither judge extracted any claim."* This is the exact cell surprise 6 is about; **4 of MAIN-SO2's 6 non-credits there are cache-only-invalid-sourced**.
2. `exporter/sol-high/a1/r0/1` MAIN-SO2 f0 — *"Run the CSV test suite and confirm the new quote, comma, and newline cases pass; no src change is needed if they do."* Notes: *"both judges returned empty claim lists: the message is a pure verification instruction asserting no defect."* ENUM-SO2's twin at the same point is the same shape — where both arms are invalid the policy is neutral by construction.
3. `dispatcher/sol-xhigh/a1/r0/4` MAIN-SO2 f0 — *"Add tests for email-only and card-plus-email lines…"* Two defects, both Sol-supported, Opus zero claims. The consensus analyst recorded the mechanism in-band: *"Opus returns zero claims on 18 of 23 cache-only-invalid rows versus 31 of 241 valid rows in judgments-opus.jsonl.gz, so this silence is plausibly an eligibility artifact rather than substantive disagreement."* Reproduced exactly from the raw file.
4. `dispatcher/sol-xhigh/a1/r0/0` MAIN-SO2 f0 — the counter-example: *"Add mixed card+email coverage…"* **credited** on `DISP-o-xd-g26` (sol 2 refs, opus 1). Notes: *"Source point is cache-only-invalid, so the finding is excluded from valid-only scoring even though both judges support the defect."* The policy also rescues real findings — 5 of 23 — so "revert to strict-v1" is the wrong fix.

### Recommendation

The defect is not the policy but that it runs **without telling the judges these rows are fully judgeable**. Opus's 78% silence is the lever. Either (a) instruct both judges that cache-only-invalid source rows are judged normally and re-run those 23, or (b) report precision twice — valid-only and semantic-v2 — so a cost assertion cannot tax a low-volume arm's quality score.

---

## Cross-cutting, unrecorded

**The two generations are on different eligibility policies, so their precision columns are not comparable as quoted.** `CAPSTONE-SCORING-RESULTS.md:69-74` compares old ENUM 88.9% with fresh ENUM-SO2 90.2%, and old MAIN 81.8% with fresh MAIN-SO2 64.7%, across that boundary. Re-adapt the old input to semantic-v2 (or the fresh to strict-v1) before any fresh-vs-old precision sentence is written again.

## Files

- Reviewed: `/Users/spannagel/dev/personal/pi-hydra.piped-discovering-minsky/experiments/trajectory-ground-truth.mjs`, `capstone-score.mjs`, `render-capstone-table.mjs`, `capstone-trajectory-judge-protocol.mjs`, `trajectory-cost-tasks.mjs`, `BENCHMARK-SPEC.md`, `CAPSTONE-JUDGE-SPEC.md`, `CAPSTONE-SCORING-RESULTS.md`, `golden-dataset.json`
- Frozen data: `experiments/artifacts/{2026-08-03-openai-capstone-producer,2026-08-02-openai-trajectory,2026-08-04-capstone-consensus,2026-08-03-openai-capstone-sol,2026-08-04-openai-capstone-opus,2026-08-04-openai-trajectory-opus}/`, `~/scratch/2026-08-04-capstone-scoring/out/`
- Probes (throwaway, outside the repo): `/tmp/repro_a.mjs`, `/tmp/repro_a2.mjs`, `/tmp/repro_a3.mjs`, `/tmp/repro_a4.mjs`, `/tmp/liveness.mjs`, `/tmp/payload_fix_probe.mjs`, `/tmp/opening.mjs`, `/tmp/inspect_close.mjs`, `/tmp/partbc.mjs`, `/tmp/examples.mjs`, `/tmp/judgecheck.mjs`, `/tmp/three_readings.mjs`, `/tmp/quotes.mjs`; extracted payloads at `/tmp/capstone-frozen/payloads/`; full draft at `/tmp/findings-draft.md`