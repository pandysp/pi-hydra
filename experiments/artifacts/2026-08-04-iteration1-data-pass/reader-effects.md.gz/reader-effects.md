Findings are durable at `/Users/spannagel/scratch/2026-08-04-lookatdata-s34/FINDINGS.json`, with probes 1–16 reproducing every number offline.

## Root cause (one defect explains all of surprise 3)

**`dataset-label-bug`, class-level.** Every anchor with `state=="end"` is a verbatim transcription of **one Anthropic opus-high driver run's terminal workspace**. Iteration 1 scores a different (OpenAI sol) driver run, whose emergent code is structurally different — so those anchors cannot match by construction.

Evidence, frozen bytes:
- `experiments/artifacts/2026-08-02-golden-dataset-v2/frame-sources.json.gz` → `tasks.dispatcher.session.rows = "experiments/artifacts/2026-08-02-cross-task-trajectory/rows-dispatcher.jsonl.gz"`, `.session.end.pointId = "dispatcher/opus-high/a1/r3/19"`; exporter end `"exporter/opus-high/a1/r3/14"`; scheduler rows `~/scratch/2026-08-01-hydra-c2-trajectory/rows.jsonl`, end `"scheduler/opus-high/a1/r3/18"`.
- `golden-dataset-frame-sources.mjs:3-11` says it outright: *"A dataset anchor is not a repo-wide search hint. It identifies one file in one judged state."*
- Byte scan of every `.gz`/`.tar.gz` under `experiments/artifacts` and `archive`: `Promise.race([started, expiry])` occurs **only** in `payloads-dispatcher-2026-08-02.tar.gz::payloads/dispatcher-opus-high-a1-r{2,3}-q{12..19}.json` and the dataset. `containing only the header row` and `totalCents` occur **only** in `payloads-2026-08-01.tar.gz::payloads/exporter-opus-high-a1-r{1,2,3}-q*.json` and the dataset.
- Cross-tab over the 6 fresh cells: `state=="seed"` **25 live / 0 never-live**; `state=="start"` **3/0**; `state=="end"` **5 live / 2 unknown / 7 never-live**. Every never-live record in the table is `state=="end"`.

I reproduced all 18 table rows and both mean blocks from frozen inputs by independent re-implementation (`probe12.mjs`). The anchor-vs-snapshot check shares no code path with `capstone-score.mjs`, so a scorer misread of the anchor bytes is independently ruled out.

## (a) The three candidates

| id | verdict | crediting | anchor | statement |
|---|---|---|---|---|
| `DISP-o-xd-g03` | **dataset-label-bug — anchor only** | sound | wrong | correct |
| `EXP-o-xe-g17` | **dataset-label-bug — anchor only** | sound | wrong | correct |
| `EXP-o-xe-g21` | **dataset-label-bug — anchor AND statement**, + crediting-precision defect | consequence yes, mechanism no | wrong | wrong |

**`DISP-o-xd-g03`** — `runAttempt` does not exist in the seed at all; the driver writes it at pointIndex 15 (sol-high) / 11 (sol-xhigh). Both realizations leave the losing POST uncancelled exactly as the statement says (`return Promise.race([attempted, timeout]).finally(...)` at xhigh; `try { return await Promise.race([...]) } finally { clearTimeout(timer) }` at high). The anchor demands the opus-high run's variable names `started, expiry`. All 41 credited entries; earliest credited points are `dispatcher/sol-high/a1/r2/15` and `dispatcher/sol-xhigh/a1/r2/11` — the exact indices where `runAttempt` appears.

**`EXP-o-xe-g17`** — the anchor is opus-high prose; this run's doc says *"An empty export is just the header"*. The issue is live at **exactly one point**, `exporter/sol-xhigh/a1/r3/14` (code has the trailer, doc still stale; the driver fixes the doc at idx 15) — and that is precisely where both judges credited it. At sol-high the driver wrote code and doc in the same step, so g17 is genuinely never live there. A correct anchor yields exclude-at-sol-high / keep-at-sol-xhigh, which is what the table has. Right denominator, wrong recorded reason.

**`EXP-o-xe-g21`** — corrects the results doc's surprise-3 wording *"the anchor bytes, not the issues, look wrong"*: true for g03/g17, **incomplete for g21**. Neither `totalCents` nor `Math.round` appears in `src/exporter.js` at any of the 16+19 points. The run's trailer is `totalAmount += row.amount` → `.toFixed(2)` — sum-then-round float drift, a different cause with the same consequence. Both judges credited on the consequence clause: **zero** of the 3 g21-matched claims across both judges mentions `Math.round`, cents, or tie-rounding. Judges never see anchors (`capstone-trajectory-judge-protocol.mjs:170` renders only `key: statement`), so this was invisible to them.

## New harness-bug, distinct from surprise 1

`capstone-score.mjs:70-81 anchorLiveAtPoint` **never reads `issue.anchors.state`**, though the dataset populates it on all 42 anchored records and frame-sources declares which run "end" means. A foreign-frame anchor is reported `never-live` instead of `unknown`. The error is **directional**: never-live → excluded → denominator shrinks → recall inflates. Credit-based re-admission rescues only credited ids — which is exactly why four never-credited records slipped through.

## Spillover: four published blocking recalls are overstated

Applying the same mechanism-vs-consequence test to the four never-credited never-live records:

- **`EXP-o-xe-g22` live by consequence** — no amount validation at any trailer-bearing point; `totalAmount += NaN` then `.toFixed(2)` prints `"NaN"` (arithmetic executed).
- **`EXP-o-xe-g27` live by consequence** — the trailer is appended unconditionally; only the label differs (`summary` vs `TOTAL`).
- **`DISP-o-xd-g24` correctly excluded** — sol-high `maskEmail` replaces the whole address with `****`, so a one-char local part is fully masked; in sol-xhigh `maskEmail` does not exist.
- **`DISP-o-xd-g11` correctly excluded** — sol-high docs line 40 shows `{ id, delivered, attempts, log: [...] }`; sol-xhigh docs carry `log` in every example.

Consequence-basis exporter blocking denominator is **9 in both configs**, not 7/6:

| cell | published | corrected |
|---|---|---|
| exporter/sol-high/MAIN-SO2 | 1/7, 2/18 | **1/9 (11.1%), 2/20 (10.0%)** |
| exporter/sol-high/ENUM-SO2 | 3/7, 5/18 | **3/9 (33.3%), 5/20 (25.0%)** |
| exporter/sol-xhigh/MAIN-SO2 | 2/6, 6/18 | **2/9 (22.2%), 6/21 (28.6%)** |
| exporter/sol-xhigh/ENUM-SO2 | 2/6, 5/18 | **2/9 (22.2%), 5/21 (23.8%)** |

Fresh means shift MAIN-SO2 blocking 30.2→27.8%, ENUM-SO2 39.4→35.9%. **No verdict sentence changes.** Iteration-2 flag, not an iteration-1 rescore.

## (b) The 33 anchor-less records

**Distribution is the headline:** 31 of 33 are scheduler — 31 of 40 scheduler actives, 9 of 15 blocking. Exporter 1 of 21, dispatcher 1 of 14. The hygiene gap is almost entirely a scheduler problem, concentrated on the column that outranks all others.

**Free resolution first:** 21 of 33 are credited by both judges somewhere → provably live by the same logic the scorer already uses for re-admission. `EXP-c-11` is credited in both exporter cells (correctly kept). `DISP-c-03` is never credited and sits in a blocking denominator of **3**, so I resolved it by hand first.

**Sample rule:** both non-scheduler records mandatory (highest per-record leverage), remainder blocking-weighted from the 12 undetermined. 10 resolved — read as an estimate, not a census.

| id | live? | evidence |
|---|---|---|
| `DISP-c-03` | **yes** | seed `maskCard` regex `/\b(?:\d[ -]?){12,15}\d\b/` present at all 25/23 points, never repaired — a real miss by both arms, not a denominator artifact |
| `EXP-c-11` | yes | credited both cells |
| `SCHED-c-08` | yes | `lastError: error.message` at all points, all 4 cells; no guard ever added |
| `SCHED-r-d20` | yes | `return store.jobs.get(id) ?? null;` all points; `structuredClone` never appears |
| `SCHED-r-d37` | yes | `store.jobs.set(job.id, { ...job });` all points |
| `SCHED-r-d33` | yes | `formatDuration` tested at every point, no `59_950` boundary case |
| `SCHED-o-g16` | yes | `runOnce` gains `finally { console.log(...) }` / `finally { printSummary(store) }` |
| `SCHED-c-13` | **no, all 4 cells** | statement needs `stats()` to partition running into two exclusive buckets; none of the four emergent implementations does — all count `running` unconditionally with `expired` as an overlapping subcount |
| `SCHED-c-15` | **no, all 4 cells** | `"Known gaps"` occurs at zero of 22/25/20/19 points |
| `SCHED-o-g08` | **no, all 4 cells** | per-point scan: doc ends on sentence-final punctuation at every point, no unbalanced fence — no truncated dead-letter section exists |

**Bias assessment.** Within-cell: **none** — both arms share the denominator. Absolute levels: scheduler recalls are understated; only 9 of 40 scheduler actives are mechanically confirmed live, 31 pass as unknown→kept. 7 of 10 sampled are genuinely live, so as-scored denominators are approximately right, inflated by ~3 harmful on the scheduler. **Cross-task is the real bias**: scheduler is essentially unfiltered (0 exclusions in 3 of 4 cells) while exporter loses 3-4 and dispatcher 2, so the means mix cells of very different denominator quality.

Bracketed both ways — **no ordering flips in either**, in any cell or any mean:
- **strict** (drop every anchor-less record not credited in that cell; lower bound on denominators, upper bound on recall): fresh MAIN-SO2 43.4% / ENUM-SO2 53.5% blocking; old ENUM 66.4% > MAIN 33.2% > F2 24.1%. The **surprise-5 effort reversal survives** (sol-high MAIN 62.5% vs ENUM 25.0%; sol-xhigh MAIN 50.0% vs ENUM 70.0%). Dispatcher sol-xhigh ENUM-SO2 reaches 2/2.
- **repair** (drop only the 3 verified-not-live): blocking untouched (all three are harmful tier); fresh scheduler any-harm denominator 40→37.

## What the anchor backfill must pin

**Rule: an anchor may only pin bytes that exist in the SEED, or a declaration regex that survives driver edits — never bytes that exist only after a particular driver's edit.**

The rule is evidenced, not asserted. The only end-anchors that survived a run change are `EXP-o-xe-g14`/`g19`: expression = the seed's own import line `import { csvField, csvRow } from "../src/csv.js";` plus `absent: ["exportOrders"]` / `["exportOrders","since"]` — live at every point of both exporter cells. `DISP-o-xd-g20`/`g26` use the **same** form and still failed, because they pinned the source run's *post-edit* import (`maskCard, maskEmail, redactLine`) while the seed imports only `maskCard, redactLine`.

Concretely:
1. Keep `state=="seed"` anchors as they are — 25/25 resolved correctly.
2. Emergent-code issues (`runAttempt`, `stats`, `maskEmail`, the trailer): declaration regex over the emergent identifier + `absent` naming the repair tokens; accept a run-dependent live-from point. Never a verbatim expression.
3. Doc-staleness issues: a two-sided predicate (code construct present AND doc assertion still contradicting), not a prose quote. `EXP-o-xe-g17`'s true window in this run is a **single point** — a prose quote cannot express that.
4. Repair statements alongside anchors where the mechanism is run-specific: `EXP-o-xe-g21`, `EXP-o-xe-g22`, `SCHED-c-13` all describe the opus-high run's implementation, not the issue.
5. **Size:** 33 records with no anchor, plus 14 `state=="end"` anchors of which only 2 are portable today. Only **4 of 42** anchored records populate `absent` — the machinery the fix needs already exists and is barely used.

One friction worth surfacing: `SCHED-c-ru07a`/`ru13a` are labelled `state:"end"` but their expressions are seed bytes, so they matched by luck; `SCHED-c-ru13b` is genuinely emergent and matched in the fresh cells while being never-live in old scheduler sol-high — that is the published table's `−1` exclusion, and a live demonstration that `state:"end"` anchors are run-lottery, not measurement.