export const meta = {
  name: 'iteration1-data-pass',
  description: 'Registered look-at-the-data pass over iteration-1 scoring: triage the surprises from raw rows and judgments',
  phases: [
    { title: 'Read', detail: 'three focused readers over raw frozen data', model: 'opus' },
    { title: 'Synthesize', detail: 'one triage synthesis', model: 'opus' },
  ],
}

const A = typeof args === 'string' ? JSON.parse(args) : args
const REPO = A.repo

const COMMON = `Registered look-at-the-data pass, iteration 1 (BENCHMARK-SPEC.md iteration protocol step 2) for pi-hydra. Repo: ${REPO}. Read experiments/CAPSTONE-SCORING-RESULTS.md first — your assignment covers part of its surprise list. Ground every conclusion in the RAW frozen data (rows, payloads, judgments, dataset records), never in summaries. Frozen inputs: consensus experiments/artifacts/2026-08-04-capstone-consensus/, producer rows experiments/artifacts/2026-08-03-openai-capstone-producer/, old rows experiments/artifacts/2026-08-02-openai-trajectory/, judges' raw responses in the four judge artifacts, dataset experiments/golden-dataset.json (version 0aadc215658a775b). Verdict vocabulary per surprise: harness-bug | dataset-label-bug | real-effect | no-issue, each with the exact evidence (file, key, quoted bytes) that decides it. You change NOTHING — findings only.`

const readers = [
  { key: 'labels', prompt: `${COMMON}\n\nYour assignment: surprises 3 and 4 (dataset-label side). (a) The three anchor-mismatch candidates DISP-o-xd-g03, EXP-o-xe-g17, EXP-o-xe-g21: for each, read the dataset record (statement, anchors, frame), the task snapshots the anchors should resolve against, and the actual judge-credited findings; decide whether the anchor is wrong (dataset-label-bug), the crediting is wrong (consensus defect), or both are fine and the scorer misread (harness-bug). (b) Sample 8 of the 33 anchor-less v1-era records across the three tasks and assess whether keeping them in denominators biased any cell in the iteration-1 table, and what the anchor backfill must pin. Return structured findings.` },
  { key: 'effects', prompt: `${COMMON}\n\nYour assignment: surprises 5 and 6 (real-effect candidates). (a) The scheduler sol-high blocking reversal: ENUM-SO2 found 2/15 blockers at sol-high but 7/15 at sol-xhigh, while MAIN-SO2 held 5/15 at both. Read every ENUM-SO2 scheduler sol-high delivered message in the raw rows and the corresponding credited/uncredited judgments: did ENUM-SO2 raise the blockers and lose them in judging, raise them outside credited form, or genuinely not raise them? Compare with the sol-xhigh rows. (b) MAIN-SO2 fresh scheduler sol-high precision 64.7% vs old MAIN 81.8%: read the 6 not-real MAIN-SO2 findings and the old MAIN not-reals — same failure modes or new ones introduced by the SO2 wording? Decide real-effect vs harness/consensus artifact, with quoted evidence.` },
  { key: 'harness', prompt: `${COMMON}\n\nYour assignment: surprises 1, 2, 7 (harness side). (a) Verify the payload-liveness walker defect on the Responses-API payload shape: reproduce on 3 concrete payloads (quote the bytes the walker misses), confirm quiet-span vacuousness was correctly documented, and state exactly what an iteration-2 fix must parse. (b) The "absolute noise" wording-vs-renderer discrepancy: read the frozen renderer and the registered metric text, state which number iteration 1 actually reported per cell and whether any cell's noise count would differ under the other reading. (c) Cache-only-invalid policy: list every cache-only-invalid point per arm in the fresh input and determine whether the policy's effect is arm-neutral or systematically disadvantages one arm (count affected findings per arm, read 4 examples). Verdicts with evidence.` },
]

const reads = await parallel(readers.map((r) => () =>
  agent(r.prompt, { label: `read:${r.key}`, phase: 'Read', model: 'opus', effort: 'xhigh' })
))

const synthesis = await agent(`${COMMON}\n\nYou are the synthesizer. Three focused readers returned these findings:\n\n=== labels ===\n${reads[0]}\n\n=== effects ===\n${reads[1]}\n\n=== harness ===\n${reads[2]}\n\nProduce the data-pass triage: every surprise from CAPSTONE-SCORING-RESULTS.md with its final verdict (harness-bug | dataset-label-bug | real-effect | no-issue), the deciding evidence in one or two sentences each, and the concrete iteration-2 work list in priority order, separating: harness fixes (land immediately), dataset label/anchor fixes (must go through the consensus protocol, never on a finder's authority), and real effects (enter the results). Where a reader's evidence is thin or two readers conflict, say so plainly instead of smoothing it over. Plain language throughout.`, { label: 'synthesize', phase: 'Synthesize', model: 'opus', effort: 'xhigh' })

return { synthesis, reads }