# v2 pool — stage B consumption guide (2026-08-02)

Built by wave 2 stage A against dataset version `4ea27b0018705940`
(pipeline commit 7eedc8b). All clustering judged by opus (subscription);
mapping reviewed cluster by cluster; one analyst correction, appended to
mapping.txt.

## Files

- `candidates.json` — 117 new source reports: 37 blind-review
  (R-BE*/R-BD*), 59 cross-task observer claims (O-XE-*/O-XD-*, including
  the 13 both-judges-not-real dispatcher claims re-entered as ordinary
  candidates), 21 code-review runner-up parts (C-RU*, 13 bullets split
  under RULING 2). Every candidate carries `frame`.
- `credit.json` — 32 reports matched onto 12 existing records. Apply at
  assemble via `--edits` addMembers. EXP-c-12's five credits re-route
  onto the split replacements (rejudge.json `inheritCredit`).
- `issues.json` — 67 novel clusters (V2-I01..67) for the full consensus
  protocol, `--source auto`. V2-I67 is the analyst correction.
- `rejudge.json` — the four audit re-judges: EXP-c-12 split pair (C12A
  blocking-precedent half + C12B formula half with its standalone
  caveat), SCHED-r-d22 and SCHED-r-d04 under the seed frame,
  SCHED-r-d36 with the corrected saveJob source fact. Each replaces its
  v1 record at assemble (`--edits` remove + new records).
- `ruling4.json` — SCHED-r-d20 + SCHED-r-d37, one confirmation
  deliberation round under the four-ruling rubric.
- `editorial.json` — SCHED-o-g02 statement narrowing for ratification.

## Flow

1. Consensus over issues.json (novel 67), rounds to convergence,
   analyst-first per round, batch-size default; `--source auto` routes
   frames mechanically (7 scheduler:session candidates, rest seed).
2. Small state dirs for rejudge.json and ruling4.json items (they need
   the four-ruling rubric; rejudge replaces, ruling4 confirms).
3. Assemble: `--base experiments/golden-dataset.json --edits <file>`
   with addMembers from credit.json, remove+append from rejudge
   outcomes, patch from editorial ratification + ruling4 outcome +
   frame flips (RD22/RD04 → seed if their re-judge stands). New records
   need anchors + reachable + precondition (check.mjs enforces
   post-v1). `--run-id 2026-08-02-golden-dataset-v2`.
4. `node --test experiments/golden-dataset.check.mjs` green, then
   freeze + rescore.

## Attention items from the mapping review

- EXP-c-04 (rejected v1) was independently re-raised by a blind
  reviewer (R-BE3-08, credited as provenance). Rejection stands unless
  stage B explicitly reopens it — do not reopen silently.
- V2-I05 may overlap EXP-unbounded-page-size (limit-as-page-size vs
  no-cap); the clusterer conservatively kept it novel. Consensus should
  individuate consciously.
- 7 scheduler candidates (5 clusters V2-I30..33 + credits C-RU03a/b,
  C-RU07b) deepen the scheduler slice AGAINST the V2 spec boundary —
  included on the parent's explicit instruction, flagged `boundaryNote`.
  Parent decides keep/drop before consensus spend.
- Many observer-sourced clusters are doc-gap/test-coverage claims
  (V2-I16..26, I49..65); v1 precedent rejects most. Judging them anyway
  is the point — the rejected pool records the reasons.
