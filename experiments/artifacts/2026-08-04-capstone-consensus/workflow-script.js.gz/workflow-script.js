export const meta = {
  name: 'capstone-consensus-analyst',
  description: 'Match Sol and Opus claims per finding, credit both-judges defects, verify adversarially',
  phases: [
    { title: 'Match', detail: 'one opus-high analyst per 27-finding batch', model: 'opus' },
    { title: 'Verify', detail: 'one opus-xhigh adversarial checker per batch', model: 'opus' },
  ],
}

const MATCH_SCHEMA = {
  type: 'object',
  required: ['batch', 'findings'],
  properties: {
    batch: { type: 'string' },
    findings: {
      type: 'array',
      items: {
        type: 'object',
        required: ['sourceKey', 'defects', 'notes'],
        properties: {
          sourceKey: { type: 'string' },
          defects: {
            type: 'array',
            items: {
              type: 'object',
              required: ['description', 'bothSupported', 'solClaimRefs', 'opusClaimRefs', 'catalogIssueIds', 'disagreement', 'novelCandidate'],
              properties: {
                description: { type: 'string' },
                bothSupported: { type: 'boolean' },
                solClaimRefs: { type: 'array', items: { type: 'string' } },
                opusClaimRefs: { type: 'array', items: { type: 'string' } },
                catalogIssueIds: { type: 'array', items: { type: 'string' } },
                disagreement: { type: ['string', 'null'] },
                novelCandidate: { type: 'boolean' },
              },
            },
          },
          notes: { type: 'string' },
        },
      },
    },
  },
}

const VERIFY_SCHEMA = {
  type: 'object',
  required: ['batch', 'verdicts'],
  properties: {
    batch: { type: 'string' },
    verdicts: {
      type: 'array',
      items: {
        type: 'object',
        required: ['sourceKey', 'defectDescription', 'upheld', 'reason'],
        properties: {
          sourceKey: { type: 'string' },
          defectDescription: { type: 'string' },
          upheld: { type: 'boolean' },
          reason: { type: 'string' },
        },
      },
    },
  },
}

const A = typeof args === 'string' ? JSON.parse(args) : args
const BATCHES = A.batches
const SCRATCH = A.scratch

const results = await pipeline(
  BATCHES,
  (b) => agent(`You are the analyst in the pi-hydra capstone two-judge consensus. Work batch file ${SCRATCH}/${b}.json (fields: input, basis, instructions, findings[]). Each finding carries the delivered observer message plus solClaims[] and opusClaims[] — the two judges' independent atomic claims with claimRefs and catalog matches[].

Follow the packet instructions EXACTLY:
1. Read every finding's message and BOTH claim lists. For depth, the raw judge responses are in experiments/artifacts/2026-08-03-openai-capstone-sol/judgments-sol.jsonl.gz and experiments/artifacts/2026-08-04-openai-capstone-opus/judgments-opus.jsonl.gz for input "fresh", and experiments/artifacts/2026-08-02-openai-trajectory/judgments-sol.jsonl.gz and experiments/artifacts/2026-08-04-openai-trajectory-opus/judgments-opus.jsonl.gz for input "old" (repo: /Users/spannagel/dev/personal/pi-hydra.piped-discovering-minsky; gunzip -c and select by sourceKey). Consult them whenever claim wording alone is ambiguous.
2. Group claims by the SAME UNDERLYING WRONG BEHAVIOR — never by wording similarity or by counting. One defect entry per distinct wrong behavior the finding's message asserts.
3. A defect is bothSupported ONLY when a Sol claim AND an Opus claim each independently support that same wrong behavior with centralSupported=true. List the exact claimRefs on each side. Never stretch a broad claim to cover a specific behavior it does not state (registered iteration-2 rule: broad atomic claims must not earn specific catalog consequences they do not state).
4. catalogIssueIds: the golden-dataset issue ids credited by BOTH judges' matches for that defect (intersection semantics — an id only one judge matched goes to disagreement, not to credit).
5. disagreement: when judges genuinely diverge (one supports, one refutes; or they match different catalog ids), record it verbatim-style in one or two sentences naming which judge holds what. null when none.
6. novelCandidate: true when a bothSupported defect matches NO active catalog issue — these are promotion candidates.
7. notes: one sentence per finding only if something needs flagging (parse oddities, cache-only-invalid caveats); empty string otherwise.

Cover EVERY finding in the batch, in order, one entry each. Return the JSON object only.`, { label: `match:${b}`, phase: 'Match', schema: MATCH_SCHEMA, model: 'opus', effort: 'high' }),
  (match, b) => agent(`Adversarial verification of a consensus-analyst batch (pi-hydra capstone). The analyst's output for batch file ${SCRATCH}/${b}.json is:

${JSON.stringify(match)}

Your job: try to REFUTE the scoring-critical decisions. For EVERY defect marked bothSupported=true AND every defect with a non-empty catalogIssueIds list, re-read the underlying finding in the batch file and the cited claims (and the raw judge responses in the artifacts named inside the batch's basis when needed; repo /Users/spannagel/dev/personal/pi-hydra.piped-discovering-minsky). Check: (a) do the cited Sol and Opus claimRefs really each support that exact wrong behavior, (b) is any credited catalog id matched by only ONE judge, (c) did the analyst stretch a broad claim into a specific consequence it does not state, (d) did the analyst merge two distinct wrong behaviors or split one. Default to upheld=false when uncertain. Return one verdict per checked defect with a one-sentence reason. Also add a verdict entry (sourceKey, defectDescription "COVERAGE", upheld, reason) stating whether every finding in the batch file got exactly one entry.`, { label: `verify:${b}`, phase: 'Verify', schema: VERIFY_SCHEMA, model: 'opus', effort: 'xhigh' })
    .then((v) => ({ batch: b, match, verify: v }))
)

const ok = results.filter(Boolean)
log(`${ok.length}/${BATCHES.length} batches matched and verified`)
return { batches: ok.length, results: ok }