Evidence complete. Writing the catalog directly as my return value.

---

# PAIN AND PATCH INVENTORY — pi-hydra judge design

**Headline: of 37 standing judge-design rules I can name from the record, 23 exist only because something failed. Ten were stated as principle before any data; three earned their place by passing a pre-registered test they could have failed. The remaining 23 are repairs. Five of them sit in patch chains three or four deep, and two of the program's two most load-bearing measured defects — the intersection floor and the per-arm precision unit — still have no fix, only fuller disclosure.**

---

## A. The catalog

### A1. The 4-level severity scale (41.7%) — the gate metric was wrong, not the judges

**What happened.** `SEVERITY-PROBE-RESULTS.md` "P1 VERDICT": exact agreement 5/12 = 41.7%, below the pre-registered 50% not-viable floor. The probe stopped.

**Root cause as diagnosed.** Not noise. `SEVERITY-PROBE-RESULTS.md` "Diagnosis": two coherent, opposite grading conventions the anchors never specified — sol grades the mechanism, opus discounts for reachability (g05, g04); on documentation opus grades task relevance, sol grades text (g07). Adjacent agreement was 91.7% in the same table, reported as ungated secondary.

**Patch.** `SEVERITY-PROBE-V2-SPEC.md` F1: decompose the judgment into `harmIfExecuted` / `reachable` / `inDeliverable`; the analyst blends afterwards.

**Standing complexity.** Yes — three judged fields plus two analyst blends replaced one.

**The catalog lesson.** `SEVERITY-V4-BLOCKING-TIER.md` "The finding" says it plainly: the informative number was adjacent-or-better 100%, present in v1 too. The scale was finer than the judges' resolution. The wrong gate metric cost one full redesign (v2's three fixes) plus `SEVERITY-V3-SPEC.md` — a complete pairwise/Bradley-Terry design written, registered, and superseded **without ever running**. That unrun spec is the receipt.

### A2. Decomposition helped but did not clear the bar (61.9%)

**What happened.** `SEVERITY-PROBE-V2-RESULTS.md` "V1 GATE": 61.9% (13/21), in the pre-registered MARGINAL band. `inDeliverable` agreement 38.1%.

**Root cause.** The decomposition worked as designed — it quarantined the definitional dispute in one field rather than fixing it. sol answers `inDeliverable=yes` on 16 of 21, opus on 3 of 21 (same doc, "The residual disagreement").

**Patch.** `SEVERITY-V4-BLOCKING-TIER.md`: re-bucket v2's existing labels — **no new judging, zero spend** — to 2 levels. Blocking-vs-rest 90.5%, any-harm-vs-none 95.2%. Drop `inDeliverable` entirely.

**Standing complexity.** Net *negative* — this is the one patch that removed machinery. The dataset schema now says `tier blocking | harmful ... never the 4-level scale, 61.9% agreement` (`GOLDEN-DATASET-DESIGN.md`, issue schema).

### A3. The clustering swallowed the strongest finding

**What happened.** `SEVERITY-PROBE-RESULTS.md` P3, structural problem 1: MAIN's p6 message names two planted defects in one sentence; the cluster judge folded the whole message into g02 and created no cluster for the TOCTOU race. MAIN's only blocking-class finding was invisible to scoring.

**Root cause.** Message-level clustering, when a message can carry several defects.

**Patch.** `SEVERITY-PROBE-V2-SPEC.md` F2 — per-claim extraction, multi-membership allowed, mapping printed. Confirmed fixed in `SEVERITY-PROBE-V2-RESULTS.md` V3 (MAIN's p6 now yields claims in both g13 and g01).

**Standing complexity.** Yes — a three-stage extract/dedupe/map pipeline with a printed mapping, plus the individuation convention it needs (RULING 2, A7 below).

### A4. The pool could only contain what some arm said

**What happened.** `SEVERITY-PROBE-RESULTS.md` P3, structural problem 2: recall was measured over the collectively-found set. The spec's own rule that planted defects enter the pool was not implemented.

**Patch.** F3 seeding (`SEVERITY-PROBE-V2-SPEC.md`), then the blind reference review (`GOLDEN-DATASET-DESIGN.md` Build step 2), described there as "the ONLY mechanism that catches an issue every arm missed AND we failed to plant".

**Standing complexity.** Yes, and it is expensive: three blind opus-xhigh passes per task, reviewers blind to planted list, golden set, prior findings, and each other. It also produced the single most useful number in the program — `GOLDEN-DATASET-V1-RESULTS.md` "Per-arm scores": 34 of 46 issues found by no arm (14 blocking).

### A5. Deliberation: 42.9% → 95.2%, zero authority-driven changes

**What happened — this one is a success, and it is the load-bearing one.** `CONSENSUS-RESULTS.md` C1: round 1 independent 9/21 = 42.9%, round 2 90.5%, round 3 95.2%, round 4 stalled. +52.3pp against a pre-registered 5pp "this is ceremony, drop it" bar. C2: 12 position changes, 8 evidence-driven, **0 authority-driven**, 4 unclassified by a deliberately conservative classifier.

**What it revised.** C3: the deliberated set adds g07 (found by F alone) as a third unanimous blocking issue, so MAIN and F **tie** at 2 of 3 on different issues. `SEVERITY-PROBE-V2-RESULTS.md` carries the headline revision at the top of the file; `DECISION-TABLE.md` "Top-tier recall — CONSENSUS SET" carries the withdrawal.

**The check that mattered.** C4: 11 of the 12 changes were the analyst's, not the judges'. The pre-registered analyst-steering check caught the analyst.

**Standing complexity.** Yes, and it is the largest single cost item in the program — `ITERATION2-JUDGE-WAVE-SPEC.md` "Spend and interruption discipline" calls the promotion step "the largest remaining subscription draw of the program".

### A6. The wrong source block — the same failure class, twice

**First occurrence.** `CONSENSUS-RESULTS.md` C4: `sourceBlock` fed the judges `task.files` (the seed) instead of `codeContext(rows)` (start and end state). 13 of 21 issues are about artifacts the driver wrote during the trajectory, so the judges correctly answered "not evidenced" and **the run measured the analyst's prompt**.

**Second occurrence.** `GOLDEN-DATASET-V1-RESULTS.md` Anomalies 1: the consensus script fed one source per task; both judges rejected seven seed-authored issues on reasons citing driver-written repairs, including a planted defect confirmed live in every run. The doc names it in-band: "Same bug class as the first C2 consensus run (wrong sourceBlock), same remedy".

**Patch.** `--source seed`, rounds 1–2 discarded for those seven only, then RULING 3 (temporal frame) written into `GOLDEN-DATASET-DESIGN.md`, then the 2026-08-02 addendum making frame routing **mechanical** at pool time because "the v1 build routed frames by a SYMPTOM filter... which the audit showed misses the accept direction".

**Standing complexity.** Yes: a `frame` field on every record, per-candidate routing, and a separate seed-frame protocol run. **A repeat failure of the same class is the strongest single entry in this catalog.**

### A7. Four conventions the rubric never specified — RULINGS 1–4

Each ruling is a patch for a specific stall, all in `GOLDEN-DATASET-DESIGN.md` "Two conventions, RULED":

- **RULING 1 (reachability, exported API is reachable by definition)** ← the standing 2-1 dissent on `s01`/lease-clock, `CONSENSUS-RESULTS.md` C3. It dissolved once the ruling was in the rubric rather than argued post-hoc (`GOLDEN-DATASET-V1-RESULTS.md` "Notable calls").
- **RULING 2 (one issue per defective expression)** ← the reference review's planted-defect match turned on it; also the v1 bundling defect.
- **RULING 3 (temporal frame)** ← A6 above.
- **RULING 4 (caller-side preconditions)** ← the v1 audit found "the ungoverned discount... carried both standing dissents (SCHED-r-d20, SCHED-r-d37) and several rejection margins, deciding labels without ever being ruled".

**Standing complexity.** Four rulings in every judging prompt, two extra record fields (`reachable`, `precondition`), and every ruling explicitly marked reversible with its "consequence if wrong".

### A8. Two instruments, two definitions of "blocking" — the patch routed around the root cause

**This is the entry least visible in the committed docs and it deserves the most attention.** It lives only in the gzipped verdict at `experiments/artifacts/2026-08-02-golden-v2-calibration/VERDICT.md.gz`.

**What happened.** `GOLDEN-DATASET-V2-SPEC.md` "Why now" item 2: the cross-task two-judge pools sat exactly one tier below golden-v1 (serious vs blocking) on all three exporter blockers — "systematic and one-sided — a protocol difference, not noise". Q1 asked whether adding the RULINGS to the pool rubric would close it.

**Result: 0 of 3 flipped.** Zero of 56 judgments said `blocking`, before or after. The RULINGS were demonstrably read (sol's reason opens "In the earlier exporter state…"; 11 of 28 rows moved elsewhere).

**Root cause as diagnosed.** The two prompts define the boundary differently: the pool probe's `HARM_ANCHORS` file "a silent failure that will bite in normal operation" under **serious**, while the consensus `RUBRIC` enumerates "silent incorrect results" under **blocking**. All three drifted issues are silent-failure mechanisms. Verdict text: "a conventions block that never touches the boundary definition cannot close a definitional gap."

**Patch.** Not a fix — a routing rule: golden tier wins by definition; pool tiers are advisory and never enter a decision table.

**Standing complexity.** Yes, and it is the wrong kind: the program now permanently maintains two instruments with two incompatible severity definitions plus a rule about which one to believe. Aligning `HARM_ANCHORS` with the consensus blocking enumeration is a registered follow-up factor test that **has never run**.

### A9. The v2 bar failure — structural honest dissent vs a 95% unanimity threshold

**What happened.** `GOLDEN-DATASET-V2-RESULTS.md` "How it was validated": raw novel convergence 63/67 = 94.0%, below the registered 95% bar. The builder failed closed.

**Root cause as diagnosed.** `GOLDEN-V2-PROTOCOL-DECISION.md`: "the four holdouts are all stable, honest disagreements, so the 95% convergence bar is now mathematically unreachable... The bar's intent was to catch a sloppy pool; the four holdouts are properties of genuinely ambiguous source contracts and one genuine severity judgment, not pool sloppiness." Three carry Sol doubting harm at all against an Opus+analyst majority; the fourth is a tier split (`DISP-o-xd-g03`).

**The bar conflated two different things** — non-convergence from a bad pool, and terminated honest dissent, which the protocol had *already* decided to record verbatim rather than average (`CONSENSUS-SPEC.md` Termination). The gate contradicted the protocol it was gating.

**Patch.** Option A: the gate is restated from "converged" to **"addressed" — converged, or terminated as a stable recorded dissent after maximum rounds**. 67/67 addressed. The raw 63/67 stays in the freeze record.

**Standing complexity.** Moderate, and unusually well-controlled: `GOLDEN-V2-PROTOCOL-DECISION.md` "Timing property" — registered and adopted while every v2 quality cell was blank and both Opus columns were unspent, so it could not be tuned toward an arm, and the write-free dry run's projection matched the build exactly.

**Its precursor is also a patch.** The recovery amendment (`GOLDEN-DATASET-V2-SPEC.md` "Recovery amendment") introduced statement repair with an eligibility test (compound or factually overbroad statements only; `V2-I02/04/05` and `RD04` explicitly ineligible) — machinery that exists only because an interrupted run left the wave one question short of its bar.

### A10. Format bias in claim counting — the capstone adapter

**What happened.** `CAPSTONE-JUDGE-SPEC.md` "Why a new adapter is necessary": 78 delivered messages but 119 emitted findings. Counting a response as one claim would give ENUM less denominator purely because its API supports an array; counting newline fragments would create the opposite bias.

**Patch.** Judge-side claim splitting into atomic defect claims, with `unsupportedExtra` attached for embellishments.

**Standing complexity.** Yes, and it did **not** fully solve the problem — see B2 below. Claim splitting is judge-side, so claim counts differ between judges and between passes (`JUDGE-TRANSPORT-AB-SPEC.md` Metrics acknowledges this explicitly).

### A11. Eligibility policy — strict-v1 → semantic-v2 → a policy that taxes the terse arm

**What happened.** `CAPSTONE-JUDGE-SPEC.md` second registered input: cache assertions "measure whether cost is comparable; they do not make a successfully parsed finding semantically unjudgeable", so `cache-only-invalid` rows entered the quality pass.

**What it then broke.** `ITERATION1-DATA-PASS.md` surprise 7 (verdict: **real-effect, the policy is not arm-neutral**): cache-only-invalid findings are MAIN-SO2 14/95 (14.7%) vs ENUM-SO2 9/169 (5.3%), only 5 of 23 credited. Incidence per point is *not* biased (26 vs 21, Fisher p=0.52). The asymmetry is arithmetic: "precision is a ratio and MAIN-SO2's denominator is 56% of ENUM-SO2's, so the terse arm pays roughly double for the same policy." The frozen reader report quantifies it: dropping the 23 moves MAIN-SO2 +9.5 precision points and ENUM-SO2 +4.9.

**And it resolved a separate published surprise.** Surprises 6 and 7 are one mechanism from both ends: fresh MAIN-SO2 64.7% vs old MAIN 81.8% is an eligibility-policy artifact, not SO2 wording — put both on one basis and it becomes 84.6% vs 81.8%, i.e. it **reverses**.

**Patch status.** A5 is a **single added sentence to the judge prompt** telling judges these rows are fully judgeable, plus a re-run of the 23 (`CAPSTONE-JUDGE-SPEC.md` "Iteration-2 staged judge work", registered verbatim, **not run**). The data pass is explicit that reverting to strict-v1 is the wrong fix: the policy also rescues 5 real findings.

**Standing complexity.** Yes — a versioned eligibility policy, a per-finding `qualitySourceValidity` field, and now a builder-hash change for one sentence.

### A12. The intersection floor — the credit rule's cost was invisible

**What happened.** `ITERATION1-DATA-PASS.md` unrecorded finding 1, called out as one of the two highest-value outputs of the pass: measured across all 18 cells, **30 catalog ids matched by exactly one judge and credited to neither, 8 of them blocking, affecting 16 of 18 cells**.

**Two published readings are not robust to the credit rule.** Surprise 5's effort reversal shrinks from 5-vs-2 to 5-vs-4; old scheduler/sol-high ENUM 6 vs MAIN 3 becomes a **6-vs-6 tie**, which touches the "ENUM dominates, F2 is dead" narrative directly. Plus one measured sub-case where both judges supported the same behavior but credited *different* catalog ids, so nothing survived.

**Root cause.** The registered rule (`CAPSTONE-JUDGE-SPEC.md` "Scoring boundary": "A catalog issue earns coverage only when both judges support and match it") is conservative in one direction only, and its cost was never reported.

**Patch — disclosure, not a fix.** A7 landed in code (`0f634da`, `capstone-score.mjs:95` `oneJudgeFloor`): the one-judge floor now sits beside every recall cell. **The intersection rule itself is unchanged.**

**Standing complexity.** One more column. The underlying asymmetry stands.

### A13. The precision column is in different units per arm

**What happened.** `ITERATION1-DATA-PASS.md` unrecorded finding 2, the other load-bearing one: findings-per-delivering-row is **MAIN-SO2 exactly 1.00** (95 rows → 95 findings, max 1) vs **ENUM-SO2 1.71** (99 rows → 169, max 6); old MAIN 1.00, F2 1.00, ENUM 2.46. "`raised` is *steer count* for the prose arms and *enumerated items* for ENUM. One MAIN steer carrying three credited ids counts as one raised item; ENUM needs three, each separately at risk."

**Root cause.** The metric structurally favors the prose arm — and it compounds with A11 in the opposite direction on the denominator.

**Patch — again disclosure.** A6 landed (`0f634da`): precision reported over all findings, valid-source-only, and per delivering row. **The raised unit is not normalized**; three numbers are printed instead of one corrected one.

### A14. One-sided judge silence — a systemic precision suppressor with no patch

**What happened.** `ITERATION1-DATA-PASS.md` unrecorded finding 5: **Opus returned zero claims for an entire batch where Sol extracted claims 17 times out of 109 fresh batches (27 findings, all auto-not-real); the reverse happened 0 times.** The frozen reader report confirms these are well-formed model decisions, not transport damage: `recovered: false`, `firstResponse == finalResponse`, ids exactly `j01…jNN`, `claims: []` — one example at `scheduler/sol-high/a1/r2/10` whose Sol side carried 4 supported claims, 2 matching `SCHED-r-d32`.

**Why it matters.** "A systemic precision suppressor that hits arms unevenly by which points they steer at." Under both-judges credit, one judge's silence is indistinguishable from a considered not-real.

**Patch.** None. A5 covers only the 23 cache-only rows (where Opus's silence is 18/23 = 78% vs 31/241 = 13% on valid rows). The remaining one-sided silences have no registered remedy.

### A15. Judges never see anchors — so a wrong statement can be credited

**What happened.** `ITERATION1-DATA-PASS.md` B3: `EXP-o-xe-g21`'s statement describes a mechanism (`totalCents`/`Math.round`) that appears nowhere in this run; the actual trailer is `totalAmount += row.amount` → `.toFixed(2)` — different mechanism, same consequence. Both judges credited on the consequence clause, and "judges never see anchors (`capstone-trajectory-judge-protocol.mjs:170` renders only `key: statement`), so this was invisible to them."

**This corrects the published surprise-3 wording** ("the anchor bytes, not the issues, look wrong"): true for g03/g17, incomplete for g21.

**Patch.** Registered as `ITERATION2-JUDGE-WAVE-SPEC.md` step 1, not run.

### A16. Anchors as a class — 33 records with none, 14 that cannot match by construction

`ITERATION1-DATA-PASS.md` surprises 3 and 4: all three tasks' anchors transcribe **opus-high** driver runs; iteration 1 scores OpenAI sol runs whose emergent code differs, so `state:"end"` anchors cannot match by construction (of 42 anchored actives: seed 25 / start 3 / end 14). Separately, 33 of 75 active records carry no anchor at all — scheduler 31 (9 blocking) — so "scheduler essentially unfiltered while exporter loses 3-4". The v1 audit had already ruled "new records enter with anchors" (`GOLDEN-DATASET-DESIGN.md` build conventions); 33 grandfathered records violate it. A2 landed (foreign-frame anchors now answer `unknown`, not `never-live` — the error was directional and inflated recall). The backfill (B1) is registered, not run.

### A17. Judge transport — the flip test and the noise floors

`JUDGE-TRANSPORT-AB-SPEC.md`, final section. Over 45 findings, discordant counts:

| pair | real/not-real | unsupported-extra | catalog sets | claim counts |
|---|---:|---:|---:|---:|
| A vs A2 (same transport, noise floor) | 5 | 0 | 9 | 10 |
| A vs B (Claude Code vs pi-OAuth replay) | 3 | 0 | 5 | 6 |
| A2 vs B | 2 | 0 | 7 | 4 |

**Verdict FLIPPABLE** — cross-transport disagreement is at or below the same-transport repeat floor on every field.

**The number a designer must actually carry is the floor itself.** The same model, same transport, same prompts, same frozen bytes disagrees with itself on **5 of 45 real/not-real calls (11%) and 9 of 45 catalog match sets (20%)**. Every recall and precision cell in the program sits on top of that. The spec's own verdict rule concedes the limit: "at n≈40 findings only large effects are detectable".

**Operational pains, both recorded in place.** The pi Anthropic route was refused at the account level in every shape including production's own (shape hypothesis explicitly REFUTED by direct test, request id recorded) — then that account-level conclusion was **overturned the same day** by replaying a captured production payload against `/v1/messages`, which drew plan quota minutes later. Three capped ablations off the working shape each still drew plan, so "the field that gets a request classified out of plan coverage remains unisolated". Standing rule: pi-side Opus judging must go through the `oauth-replay` transport with a captured production payload as its shape source.

### A18. Replay and identity drift

`CAPSTONE-JUDGE-SPEC.md` "Replay preflight": the old input must run at commit `369ed58` (builder `df3cc0f57a725965`) against frozen dataset bytes; "the current working judge and working dataset are not substitutes: both have advanced since Sol answered". `ITERATION1-DATA-PASS.md` unrecorded finding 7 records the residue: builder hashes differ between generations (old `df3cc0f5…` vs fresh `5880bf01…`); the eligibility difference accounts for the finding-set difference, but the judges also saw differently-constructed prompts — an **unmeasured residual on every fresh-vs-old sentence in the program**.

---

## B. Patch chains — depth is the real signal

1. **Severity scale:** 4-level gate → decompose (3 fields, 2 blends) → collapse to 2 binary axes + drop `inDeliverable`. Depth 3, plus one complete design (`SEVERITY-V3-SPEC.md`) written and superseded unrun.
2. **Eligibility:** strict-v1 → semantic-v2 (rescues 5 real findings) → A5 clarification sentence (registered, unrun) → and semantic-v2 is itself now a documented non-neutrality with A6 dual-reporting layered on top. Depth 4, tail open.
3. **Convergence bar:** 95% unanimity → recovery amendment (eligibility-limited statement repair) → Option A gate redefinition. Depth 3.
4. **Source and frame:** wrong source block (twice, same class) → RULING 3 → mechanical frame routing at pool time → anchors as the unresolved tail (33 anchor-less, 14 non-portable, B1 unrun). Depth 4, tail open.
5. **Pool construction:** message clustering swallow → per-claim extraction → RULING 2 individuation → split bundled reports (v1 audit) → matching refinement for broad claims (42 multi-match claims, registered in `BENCHMARK-SPEC.md`, unrun). Depth 5, tail open.

---

## C. The standing-rule ledger

**Design-first (10)** — stated as principle before any failure:
two judges and both must credit for coverage or promotion (`SEVERITY-PROBE-SPEC.md` P1; `GOLDEN-DATASET-DESIGN.md` Promotion guard) · judges never see arm labels or arm counts (`SEVERITY-PROBE-SPEC.md` Rules) · judges see catalog statements but not tiers, votes, consensus, planted labels, arm, route, or cost (`CAPSTONE-JUDGE-SPEC.md` Frozen questions) · disagreement recorded verbatim, never averaged · zero producer spend for judging · derived fields read against raw text before quoting (the 96eff06 rule) · SPEC pre-registered before data with thresholds (`INDEX.md` Convention) · blocking outranks lexicographically, quality/cost/delivery never fused, weighted recall is convenience only (`BENCHMARK-SPEC.md` Reading rules) · evaluator freeze within an iteration, fixes as versioned follow-ups · support and matching are separate questions.

**Earned (3)** — passed a pre-registered test they could have failed:
three-participant deliberation to convergence (`CONSENSUS-RESULTS.md` C1, +52.3pp against a 5pp ceremony bar) · the analyst as an independently-labelling third participant (C4 caught the analyst, 11 of 12 moves) · anonymised participants (C2, zero capitulation).

**Patch-only (23)** — entered after a specific documented failure and justified by nothing else:
decomposed judgment · two binary axes only · `inDeliverable` dropped · per-claim extraction with printed mapping · planted-defect pool seeding · blind reference review · RULING 1 · RULING 2 · RULING 3 · RULING 4 · `codeContext(rows)` as source · `--source seed` and mechanical frame routing · golden tier wins / pool tiers advisory · bundled reports split into candidates · two-value rejection vocabulary · new records enter with anchors · precision-pass statement repair with an eligibility test · Option A "addressed" gate · judge-side claim splitting · `semantic-v2` eligibility · builder-hash fingerprinting and pinned replay · one format-only correction turn preserved in provenance · checkpoint-per-batch with drift-refusing resume.

**Preventive, no documented triggering failure (1):** the adversarial verification stage — 14 opus-xhigh verifiers instructed to refute scoring-critical credits and default to refusal when uncertain (`CAPSTONE-JUDGE-SPEC.md`, cross-judge consensus execution record: 6 credits refuted, 1 skipped, 7 analyst resolutions recorded in-band).

**Registered but unspent — not standing rules, and must not inflate the count:** everything in `ITERATION2-JUDGE-WAVE-SPEC.md` (steps 1–6), A4 and A5 in `CAPSTONE-JUDGE-SPEC.md`, the broad-claim matching refinement in `BENCHMARK-SPEC.md`, and the `HARM_ANCHORS` boundary-alignment factor test from the Q1 verdict.

**Count: 23 of 37 standing rules are patches — 62%.** The severity metric is the only place where a patch made the design *smaller*.

---

## D. Pains that still have no fix

Separated deliberately, because a designer will otherwise read the iteration-2 commits as closure:

| pain | status |
|---|---|
| Intersection floor (30 one-sided ids, 8 blocking, 16/18 cells; two orderings not robust) | **disclosed, not fixed** — the floor is printed beside recall (`capstone-score.mjs:95`); the rule is unchanged |
| Per-arm precision units (1.00 vs 1.71 findings/row) | **disclosed, not fixed** — three precision variants printed; `raised` still means different things per arm |
| Opus one-sided zero-claim batches (17/109, reverse 0) | **no patch at all** beyond the 23 cache-only rows |
| `HARM_ANCHORS` vs consensus `RUBRIC` blocking boundary | **routed around, never fixed**; alignment test never run |
| Judges never see anchors, so statement/anchor mismatch is invisible | registered (B3), unrun |
| 33 anchor-less records, 14 non-portable end anchors | registered (B1), unrun |
| Cross-generation builder-hash residue | registered (A4), unrun |
| Same-transport self-disagreement floor: 5/45 real-not-real, 9/45 catalog sets | measured, accepted, **unaddressed by any rule** |

---

## E. The endorse/refute idea — not in the repo record

I searched the committed docs, all gzipped artifacts, and the scratch dirs. The word "endorse" appears exactly once in the entire repository, and only incidentally, inside a verifier's reason string in `artifacts/2026-08-04-capstone-consensus/workflow-journal.jsonl.gz` ("Opus explicitly endorses the finding's described requeue behavior"). **There is no registered endorse/refute judge-design proposal.** If it exists, it is live-conversation context, not repo record — say so rather than citing it.

What the record *does* contain, and what such a design would be answering:

- The three pains it maps onto are A12 (intersection floor), A14 (one-sided zero-claim silence), and A10/A13 (judge-side claim splitting producing incomparable claim counts). All three are consequences of the same structural choice: **two judges answering the same question independently, with agreement required for credit.**
- **The mechanism already exists in this program under a different name.** The consensus stage runs 14 opus-high matchers followed by 14 opus-xhigh adversarial verifiers instructed to refute credits and default to refusal (`CAPSTONE-JUDGE-SPEC.md`, cross-judge consensus execution record). That is propose-then-refute, one layer above judging. An endorse/refute judge design is not new machinery — it is promoting an existing consensus-stage mechanism up into the judging stage itself. That framing is worth putting in front of the designer.
- The cache-clarification idea *is* in the record and is precisely scoped: one verbatim sentence appended to the judge instructions for 23 findings only, recorded as a builder-hash change (`CAPSTONE-JUDGE-SPEC.md` A5).

---

## F. Confidence flags — carry these or the evidence degrades to summary

The data pass is explicit about what it did and did not re-derive (`ITERATION1-DATA-PASS.md` "Where the evidence is thin"):

- **Validation anchor:** the synthesizer independently reproduced all 18 published blocking-recall cells from frozen inputs before accepting any reader claim. Corrections are measured against a verified baseline.
- **Not re-derived, carried at reader confidence:** the 17/109 zero-claim count, the `bothNotReal` support-reading correction (+1 in two cells), the per-point liveness minima behind the quiet-span analysis, and the labels reader's per-point code reads for the 10 sampled records.
- **The union-rule counterfactual is the synthesizer's own proxy** — raw judge matches filtered on `centralSupported !== false`, without the consensus protocol's adversarial verification. It is an **upper bound**, and the evaluator freeze forbids it touching the iteration-1 table.
- **The 33 anchor-less records were sampled, not censused** — 10 of 33 resolved by hand (7 live, 3 not). The distribution (31 of 33 scheduler) is exact; the liveness rate is an n=10 estimate.
- **No reader contradicted another.** The apparent 12-vs-12 conflict resolved into two genuinely distinct diffs, both verified.
- Every per-arm score in the severity arc rests on **one trajectory**: 3 unanimous blocking issues means one flip moves an arm 33pp (`CONSENSUS-RESULTS.md` Limits). The agreement numbers (n=21) are the solid part.
- **Nothing in the iteration-1 table is a lock-in number.** `CAPSTONE-SCORING-RESULTS.md` opens by saying so; `BENCHMARK-SPEC.md` Iteration protocol requires an iteration whose data pass surfaces no dataset-label bugs before the set is final, target iteration 3. Iteration 1 surfaced several.

---

## G. The five things a designer must not repeat

1. **Do not gate on a resolution the judges do not have.** The 41.7% failure and one discarded design cost came from a 4-level scale; the answer (adjacent-100%) was in the first probe's own table, reported as ungated secondary. Pick the gate metric by asking what resolution the elicitation actually supports.
2. **A conventions block cannot close a definitional gap.** Q1: 0 of 3 flipped, 0 of 56 judgments said blocking either way, because the two prompts define the boundary in incompatible words. If two instruments must agree, align the definitions, not the surrounding conventions.
3. **Feed the judge the state the issue is about.** Two runs measured the analyst's prompt instead of the arms, by the same mechanism, weeks apart. Frame routing must be mechanical and derived at pool time — a symptom filter misses the accept direction.
4. **A conservative credit rule has a cost, and it must be printed.** Both-judges intersection silently dropped 30 catalog matches (8 blocking) across 16 of 18 cells and made two published orderings non-robust. Any asymmetric rule needs its counterfactual reported beside it from day one.
5. **A metric must mean the same thing in every cell.** `raised` counts steers for prose arms and items for enumerating arms; `semantic-v2` taxes the low-volume arm twice over for identical incidence. Both are pure arithmetic, both will recur in any future run pairing a terse arm with a verbose one, and neither is fixed today — only reported three ways.