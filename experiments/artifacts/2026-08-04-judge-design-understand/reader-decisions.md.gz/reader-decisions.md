# JUDGE-SYSTEM DECISION INVENTORY (pi-hydra, state as of 2026-08-04)

**Cost currency.** Only one dollar figure exists in the whole judge system: **$12.9608 of *producer* spend** (six OpenAI capstone driver cells, 260 observer calls — `BENCHMARK-SPEC.md` §Registered OpenAI production wave). Every *judgment* is $0-metered: Sol = `gpt-5.6-sol` on the OpenAI subscription via pi, Opus = `claude -p`/Claude-CLI, analyst = the coordinator session, auditors/matchers = opus-5 high/xhigh subagents (`GOLDEN-DATASET-V2-SPEC.md` §head, `CONSENSUS-RESULTS.md` §head). So the real cost basis per row is **judge calls / batches / rounds / agent-runs**, priced in plan-window (resets ~11pm Europe/Berlin) — that constraint, not money, is what forced checkpoint-per-batch and the resume machinery (`GOLDEN-DATASET-V2-SPEC.md` §Spend; `ITERATION2-JUDGE-WAVE-SPEC.md` §Spend and interruption discipline).

## The decider ladder (sorted by who decides, not by pipeline stage)

| tier | decider | transport | where it decides |
|---|---|---|---|
| 0 | **code, no model** | — | eligibility/extraction, frame derivation, anchor liveness, denominators, checker invariants, version hash |
| 1 | **one judge (Opus)** | `claude -p` | clustering / individuation; matching new reports onto existing records |
| 2 | **two judges independently (Sol + Opus)** | pi + claude-cli | atomic claim splitting, support, catalog matching (capstone); pool tiering (advisory only) |
| 3 | **three participants (Sol + Opus + analyst)** | pi + claude-cli + session | dataset tiering, statement repair, promotion |
| 4 | **analyst alone** | session | the four RULINGS, pre-clustering splits, credit resolutions, verdict prose, triage |
| 5 | **workflow agents (opus high/xhigh)** | subagents | blind reference reviews, v1 lens audit, 28-agent consensus stage, data-pass readers |
| 6 | **Andreas** | — | severity delegation, Option A gate, scoring-design delegation, contract pick, concurrency amendment |

**The load-bearing asymmetry:** individuation (row D8) is decided by **one judge, one call, no deliberation, no second vote** — and it sets the denominators and decides whether a claim is coverage credit or a novel defect ("a wrong match silently converts a new defect into coverage credit", `golden-dataset-pool.mjs` CLUSTER_PROMPT_V2). Tiering the *same* issue costs **three participants and up to six rounds**. Effort is spent where agreement was already measured at 90.5%, and not spent where nothing has ever been measured.

---

## A. Dataset building

| # | decision | decider | input → output schema | volume (measured) | cost basis |
|---|---|---|---|---|---|
| D1 | Which defects exist by construction (planting) | analyst, in repo code | task seed → `{id, target, expression, declaration, identifier, file}` (`trajectory-cost-tasks.mjs` `TRAJECTORY_TASKS[].defects`) | **10**: scheduler 4, exporter 3, dispatcher 3 | authoring only |
| D2 | Independent discovery (blind reference review) | opus-5 xhigh, 3 blind passes per task | seed files only → `{statement, defectiveExpression, file, consequence, trigger, confidence}` | scheduler 35+32+26 = 93 raw → **44 distinct**; exporter 6+6+11 = **23**; dispatcher 5+4+5 = **14** | 6+3 agent passes, ~190s each, $0 |
| D3 | Observer pool (what arms actually claimed) | mechanical harvest from frozen artifacts | delivered messages → candidate statements | v1 **21** (C2); v2 **59** observer candidates (spec names exporter 37 / dispatcher 47 *raised*, incl. 13 both-judges-not-real dispatcher claims re-entered) | $0, replay |
| D4 | Code-review candidates | `/code-review max` run | findings → `{summary, failure_scenario, file}` | v1 **15** top findings; v2 **13** runner-up bullets | $0, one prior run |
| D5 | **Pre-clustering statement splitting** | **analyst alone, hardcoded in code** | runner-up bullet → 1..3 statements (`RUNNER_UP_SPLITS`, `golden-dataset-pool.mjs:154-196`) | 7 of 13 bullets split → **21 parts**; task per bullet also hardcoded (`RUNNER_UP_TASK`) | free; no protocol, no schema, no second reader |
| D6 | Task assignment | mechanical `taskOf()` + hardcoded map | source record → `scheduler\|exporter\|dispatcher` | all 117 v2 candidates | free |
| D7 | Temporal frame (which code state an issue is about) | mechanical `frameOf()` from provenance | provenance → `seed \| session` | v2: all 117 candidates carry `frame`; 67 novel clusters routed `--source auto` (README: 7 scheduler:session, rest seed) | free |
| D8 | **Individuation / clustering** | **ONE judge (Opus, subscription)**; analyst reviews `mapping.txt` | candidate list + binding RULING 2 text + 2 worked examples → `{clusters:[{members[], statement}]}` | v1 **90 reports → 72 clusters** (13 multi-member + 59 singletons, bijection); v2 **117 → 67 novel clusters**, 1 analyst correction (V2-I67) | ~1-2 judge calls per pool |
| D9 | Match new report onto an existing record (credit vs novel) | same one judge, `CLUSTER_PROMPT_V2` | new reports + existing actives *and rejections* → `{existing: id\|null, members[], statement}` | **32 reports credited onto 12 existing records** | inside D8's calls |
| D10 | **Tier: `blocking` / `anyHarm`** | **3 participants**, analyst labels first (independence proof file) | RUBRIC + 4 RULINGS + task/frame source + statements → `{id, blocking, anyHarm, reason}` | v1 ~**40 calls / 7 rounds / 2 protocols**; v2 ≈ **80 calls**: novel 67 clusters over 6 rounds = 50, audit-rejudge 5 issues over 5 rounds = 20, precision 2 issues over 3 rounds = 6, RULING-4 confirmation 2, editorial 2 | largest recurring subscription draw |
| D11 | **The four RULINGS** (reachability, individuation, temporal frame, caller-side preconditions) | **analyst alone**, marked "reversible", written into the rubric so labels are *produced* under them | prose → binding prompt block (`golden-dataset-consensus.mjs` `RULINGS`) | 4 rulings, dated 2026-08-01/02 | free |
| D12 | **The scale itself** (4 levels → 2 binary axes; `inDeliverable` dropped) | analyst, from re-bucketing existing labels — **zero new judging** | v2 probe labels (n=21) → agreement table | 4-level 61.9% · 3-level 66.7% · **blocking-vs-rest 90.5%** · **any-harm 95.2%** · `inDeliverable` 38.1%, adjacent-agreement 100% | $0 (`SEVERITY-V4-BLOCKING-TIER.md` §The finding) |
| D13 | Statement-repair eligibility (may a stalled statement be rewritten?) | analyst, registered *before* the batch, replacement text fixed in the spec | stalled cluster + raw reasons → eligible/ineligible + verbatim new statement | eligible: `CL38`, `CL52`; ineligible: `V2-I02/04/05`, `RD04` | 6 judge calls (the precision pass) |
| D14 | Rejection recording | protocol + checker-enforced vocabulary | → `consensus: not a real defect` \| `real, individuated onto <id> under RULING 2` | v1 **26** rejected (all hardcoded to the first value), v2 **61** | free |
| D15 | Anchors (what pins liveness) | analyst/builder; checker enforces on post-v1 records | → `{expression, file, match: literal\|regex, state}` + `reachable` + `precondition` | **42 of 75 anchored**, 33 anchor-less (v1-grandfathered); anchored split seed 25 / start 3 / **end 14** (only 2 portable) | free |
| D16 | Dataset validity | 8 offline invariants, zero calls (`golden-dataset.check.mjs`) | dataset → pass/fail: full schema; rejected schema+reason vocabulary; unique slug ids; **version = sha256 over (id, task, statement, tier) of actives**; no planted defect dropped; dedup mapping total across issues+rejected; anchors resolve in their judged frame; unresolved carries dissent | **8/8** green on v2 | free, runs on every change |
| D17 | v1 consistency audit | **3 lens auditors + 1 synthesizer** (opus workflow); auditors flag, never edit | v1 46 active + 26 rejected → flags triaged `harness-bug \| dataset-label-bug \| real-effect \| no-issue` | produced 5 re-judges, 2 RULING-4 confirmations, 1 editorial ratification | 4 agent runs |
| D18 | Convergence gate / freeze | builder fails closed at <95%; **Andreas** restates the gate | 63/67 = **94.0%** → Option A: "every cluster must be ADDRESSED — converged, or terminated as recorded dissent" | one decision, one word ("let's do Option 1"); build reproduced the dry-run projection exactly | free |
| D19 | **Calibration** | 2 judges, one factor varied (RULINGS in/out of the pool prompt) | frozen 28-candidate exporter pool, base-prompt sha `aa289b82…` vs rulings-prompt sha `421c5f38…` → before/after tiers | **0 of 3 flipped**, 0 of 56 judgments ever said `blocking`, 11/28 rows moved inside none↔minor↔serious → pre-registered "deliberation is load-bearing" reading fires | **2 judge calls, $0** |

**Dataset outputs of record.** v1 `4ea27b0018705940`: 46 active (17 blocking) + 26 rejected. v2 `0aadc215658a775b`: **75 active (27 blocking, 48 harmful) + 61 rejected**; per task scheduler 15+25, exporter 9+12, dispatcher 3+11; 4 dissents carried verbatim.

---

## B. Scoring / credit (the capstone)

| # | decision | decider | input → output schema | volume (measured) | cost basis |
|---|---|---|---|---|---|
| C1 | What counts as a judgeable finding | mechanical (`deliveredFindings`, `buildFindingItems`), policy `strict-v1` \| `semantic-v2` | frozen rows → finding items + `qualitySourceValidity: valid\|cache-only-invalid` | fresh **264**; old **119** strict-v1 / **131** semantic-v2 but packet holds **107** (12 run-end unjudgeable) | free |
| C2 | **Splitting a delivered finding into atomic defect claims** | **each judge independently**, inside the same call | delivered text + visible driver transcript + exact file state + catalog statements → `findings[].claims[]` | Sol fresh 264/264 in **109 batches**; Opus fresh 264/264 in **109 batches**; Sol old 107 in **29 batches**; Opus old 107 in **29 batches** (3 shards, concurrency-3 amendment) | ~276 judge calls total, $0 metered |
| C3 | Is the central finding supported? does it add unsupported material? | same call, `SUPPORT_POLICY` | → `centralSupported`, `unsupportedExtra` (booleans) | policy calibrated on 20 labelled cases: Opus 18/20 → 20/20, Sol 20/20 | inside C2 |
| C4 | Which catalog issues this claim matches | same call; judge sees **statements only** — no tiers, votes, planted labels, arm, route, cost, **and no anchors** | → `matches: [catalog keys]`; "same wrong behavior in the same code"; shared function name or downstream consequence is not a match | 30 catalog ids credited on fresh, 16 on old | inside C2 |
| C5 | **Aligning the two judges' independent claim lists** | **28-agent analyst workflow**: 14 opus-high matchers (one per 27-finding batch) + 14 opus-xhigh adversarial verifiers instructed to default to refusal | packet (side-by-side claim refs, deliberately *not* pre-aligned) → defects with `bothSupported, catalogIssueIds, disagreement, novelCandidate, verifierUpheld, credited` | fresh: 264 findings → **263 credited defects / 30 catalog issues / 143 disagreements / 34 novel**; old: 107 → **140 / 16 / 70 / 33**; 14/14 coverage checks passed | 28 agent runs |
| C6 | Resolving verifier refutations | **analyst alone**, 4-value vocabulary in code (`capstone-consensus-resolve.mjs`) | → `uphold-refutation` \| `analyst-direct-verdict-uphold` \| `restore-credit-drop-novel` \| `restore-narrowed` (+ optional `carveOut`) | 6 refuted + 1 skipped → **7 resolutions** (2 upheld, 2 narrowed with carve-out, 2 novel-flag dropped, 1 direct verdict) | free, fail-closed |
| C7 | **Catalog credit rule** | registered metric: **intersection** — both judges must match the same id | credited defects → per-cell recall numerator | measured cost: **30 ids matched by exactly one judge and credited to neither, 8 of them blocking, affecting 16 of 18 cells** | free |
| C8 | Liveness / denominator per cell | mechanical `anchorLiveAtPoint` + cell-wide re-admission of credited-but-never-live ids | active issues of task − never-live + re-admitted | net exclusions: dispatcher −2, exporter −3, old scheduler sol-high −1; **33 anchor-less records stay in every denominator** | free |
| C9 | Precision | `real / raised`, `raised` = findings | → per-cell ratio + absolute noise | fresh means MAIN-SO2 69.8% vs ENUM-SO2 80.6%; old MAIN 85.4% / F2 85.5% / ENUM 87.1% | free |
| C10 | Noise column | registered as both-judges-not-real; renderer computes `raised − real` | → integer per cell | **all 18 cells differ** between the two readings | free |
| C11 | Quiet-span deliveries | mechanical, files basis | driver-visible deliveries inside pre-registered quiet span | **0 in all 18 cells — vacuous by construction** | free |
| C12 | **The verdict sentence** | **analyst prose** under registered reading rules | columns → ranking | rules: blocking outranks lexicographically; 2:1 weighted recall is scan-only; ties broken in prose; no cross-task summing; evaluator freeze within an iteration | free |
| C13 | Surprise triage (iteration protocol step 2) | 3 opus-xhigh readers + 1 synthesizer who **independently reproduced all 18 blocking-recall cells** before accepting any reader claim | raw rows/payloads/judgments → `harness-bug \| dataset-label-bug \| real-effect \| no-issue` | 7 surprises triaged + **7 unrecorded findings**; 4 agent runs | free |
| C14 | **Promotion of novel candidates** | design doc: both judges ≥ harmful + dedup + votes recorded. Tightened in `CAPSTONE-JUDGE-SPEC.md` §Scoring boundary: **Sol + Opus + analyst deliberation through the dataset protocol**, then version bump + free re-score | supported-unmatched claim → new dataset record | **NEVER EXECUTED.** 67 staged (34 fresh + 33 old); dedup against v2 actives *and* rejections is step one and has not run | forecast: "the largest remaining subscription draw of the program" |

---

## C. Governance / meta decisions

| # | decision | decider | record |
|---|---|---|---|
| G1 | Severity is settled by judges + analyst, no human sign-off | **Andreas** | "I do not want to review the set. It is your and the two judges' job." (`CONSENSUS-SPEC.md` §Mandate) |
| G2 | Scoring design delegated ("separate scores or fused — part of your job"), registered before any judged coverage existed | Andreas → analyst | `BENCHMARK-SPEC.md` §head + §Scoring design |
| G3 | Deliberation is worth keeping | pre-registered C1 test | 42.9% → 95.2%, **+52.3pp**, far above the 5pp "ceremony" bar; round 4 moved nothing → clean stall |
| G4 | Consensus is evidence-driven, not authority-driven | pre-registered C2 test, verbatim reason reading | C2 run: 12 changes, **8 evidence / 0 authority / 4 unclassified**; v1 build: 57 changes, **34 evidence / 0 authority / 23 unclassified**; analyst moved most in both (11/12 and 34/57) |
| G5 | Participants anonymised to each other; never see arm labels | protocol rule | `CONSENSUS-SPEC.md` §Rules |
| G6 | Evaluator freeze within an iteration; metric fixes land between iterations, versioned | Andreas's iteration protocol | dataset is FINAL only after an iteration whose data pass surfaces no dataset-label bugs (target: iteration 3) |
| G7 | Pool tiers are **advisory**; a golden match takes the golden tier by definition | analyst, from D19's pre-registered reading | calibration VERDICT §Protocol rule |

---

## Known defects, by row (all documented in-repo; descriptive, not proposals)

- **D5** — 7 of 13 runner-up bullets split by the analyst *in a code constant*, with the task assignment hardcoded too. No protocol, no schema, no second reader; the only visibility is `mapping.txt`.
- **D7** — v1 routed frames by a *symptom filter* and missed two records (`SCHED-r-d22`, `SCHED-r-d04`); v2 replaced it with mechanical provenance routing.
- **D8/D9** — single-judge, single-call, no deliberation, no adversarial check; the prompt itself names the failure mode it cannot guard against.
- **D10** — v1's first round-1 run fed judges the seed instead of `codeContext(rows)`; 13 of 21 issues were about driver-written artifacts, so the run measured the analyst's prompt, not judgment. Same bug class recurred in the v1 build (7 seed-authored issues rejected on driver-repair reasons, including a planted defect) — caught only because `golden-dataset.check.mjs` fails exactly that.
- **D11** — the analyst authors the RULINGS, votes under them, and resolves disputes about them. No independent ratification step exists.
- **D15** — anchors for **all three tasks** transcribe **opus-high** driver runs (`scheduler/opus-high/a1/r3/18` etc.). Iteration 1 scored OpenAI Sol runs, so `state:"end"` anchors cannot match by construction — a class-level dataset-label bug. 33 of 75 actives have no anchor at all (scheduler 31, of which 9 blocking), making liveness mechanically unresolvable for 44% of the catalog.
- **D19** — the calibration that ran compares two *instruments* to each other. The mechanism it found: the pool probe's `HARM_ANCHORS` puts "a silent failure that will bite in normal operation" under **serious**, while the consensus `RUBRIC` puts "silent incorrect results" under **blocking** — the two instruments define the boundary differently. **The human calibration SEVERITY-V4 named as the surviving job of the authored gold set — "does the judges' blocking set match Andreas's own top picks" — has never been run**; `GOLD-SET-DRAFT-FOR-REVIEW.md` was retired as a review artifact when G1 delegated severity. **Nothing in this program has ever checked the judge system against Andreas's own judgment.**
- **C1** — the old packet is neither a clean `strict-v1` nor a clean `semantic-v2` basis (119 vs 131 vs 107, two compounding 12-finding gaps); `judgeBuilderHash` also differs between generations (`df3cc0f5…` vs `5880bf01…`), an unmeasured residual on every fresh-vs-old sentence.
- **C4** — judges never see anchors (`capstone-trajectory-judge-protocol.mjs:170` renders `key: statement` only). That is why the `EXP-o-xe-g21` statement/anchor mismatch was invisible to them: both credited on the consequence clause while neither `Math.round` nor `totalCents` exists anywhere in that run.
- **C7** — the intersection rule's cost is currently invisible in the table. A union proxy moves 5 cells and breaks two published readings: the "effort-dependent reversal" shrinks 5-vs-2 → **5-vs-4**, and old scheduler sol-high ENUM 6 vs MAIN 3 becomes a **6-vs-6 tie**.
- **C8** — payload liveness walker blind: `trajectory-ground-truth.mjs:121` iterates `payload?.messages`; **0/131 payloads have `.messages`, 131/131 have `.input[]`**. `anchorLiveAtPoint` ignored `anchors.state`, reporting foreign-frame anchors as `never-live` (directional: shrinks denominators, inflates recall). Both fixed in the iteration-2 scorer.
- **C9** — `raised` is in **different units per arm**: MAIN-SO2 exactly 1.00 findings per delivering row (95 rows → 95 findings) vs ENUM-SO2 1.71 (99 → 169); old ENUM 2.46. The metric structurally favours the prose arm. Compounding in the opposite direction: the `semantic-v2` cache policy is not arm-neutral (MAIN-SO2 14/95 = 14.7% cache-only-sourced vs ENUM-SO2 9/169 = 5.3%; incidence per *point* is unbiased, Fisher p=0.52 — the asymmetry is pure ratio arithmetic).
- **C10** — `bothNotReal` tests presence of claim refs, not support; the faithful reading moves two cells.
- **C11** — the column reads 0 correctly, but the published *reason* is wrong: quiet requires zero live plants and the minimum live-per-point is **3 in every one of the 8 cells**.
- **C5** — Opus produced one-sided zero-claim batches on **17 of 109 fresh batches (27 findings, all auto-not-real); the reverse happened 0 times** — a systemic precision suppressor hitting arms unevenly. Reader-reported, not independently re-derived.

## Registered but unspent (the cheap redesign surface — nothing frozen here)

| item | what it would decide | staged in |
|---|---|---|
| Promotion of 67 novel candidates (34 fresh + 33 old, dedup unrun) | whether the set grows from discovery | `ITERATION2-JUDGE-WAVE-SPEC.md` §5 |
| Anchor-backfill rule as a RULING-style confirmation | 33 anchor-less + 12 non-portable end-state anchors | ibid. §2 |
| 6 dataset record repairs (`DISP-o-xd-g03`, `EXP-o-xe-g17/g21/g22/g27`, `SCHED-c-13`) | anchor and statement semantics | ibid. §1 |
| A5 cache-only re-judge (23 fresh findings, one added prompt sentence, new builder hash) | whether the eligibility tax is judge silence | `CAPSTONE-JUDGE-SPEC.md` §Iteration-2 staged |
| A4 old-basis unification (12 findings under `semantic-v2`) | fresh-vs-old comparability | ibid. |
| Judge transport A/B (Claude Code CLI vs pi/anthropic, ~40-finding sample, 3 passes incl. a repeat noise floor) | **does the carrier change Opus's verdicts** | `JUDGE-TRANSPORT-AB-SPEC.md` — registered, not run |
| `HARM_ANCHORS` ↔ consensus-`RUBRIC` boundary alignment | the surviving candidate mechanism for the one-tier calibration gap | calibration VERDICT §Anomaly pass, "registered follow-up factor test" |
| v2 final freeze stage (`golden-dataset-v2-freeze-stage.mjs`) | immutable final artifact vs provisional checkpoint | prepared, zero-call, not yet run |