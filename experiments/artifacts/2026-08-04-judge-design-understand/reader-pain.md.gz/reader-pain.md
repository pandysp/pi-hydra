## GOALS AND HARD CONSTRAINTS — evidence for the judge-design rethink

Everything below is from the repo record and the vault-recorded user messages (`~/main-workspace/notes/side-projects/pi-hydra-user-messages-full.md`, cited as msg-id). Where the record is silent, I say so — the silences are load-bearing for this rethink.

---

## 1. The end use: what the one table has to carry

**The decision.** Andreas's goal message (msg S2-115/116, 2026-08-02): "*At the end of the day I want to be able to lock in design(s)*", from "*one table across all the runs where we have cost per observation, cost per trajectory in percentage to the driver and some kind of quality score, probably precision and recall or something, where blocking findings are scored higher than non-blocking ones (idk how to do this, this will be part of your job, separate scores or fused, no idea)*." The scoring design was explicitly delegated. The columns were later fixed in msg S2-118 item 11: cost/observation, observer-as-%-of-driver, blocking recall, any-harm recall, precision, absolute noise, quiet-span deliveries, weighted-recall convenience value.

**What the decision actually is.** Not "which observer is best in general" but: pick the shipped observer contract, possibly split by provider or head-kind, where "*the branches should be ideally cheap, i.e. the instructions and not code branches. Unified API is still preferred but not absolute if the gains are worth the split*" (msg S2-115/116). So the table must support (i) a cost-vs-quality tradeoff call between a small number of named arms, and (ii) a per-provider split-or-not call.

**Trust properties that follow — decision-relative, not "good measurement" in general:**

1. **It must discriminate between the arms actually on the table, at the margins that exist.** It currently may not. `ITERATION1-DATA-PASS.md` §Unrecorded findings 2: the precision column is *in different units per arm* — MAIN-SO2 emits exactly 1.00 findings per delivering row (95 rows → 95 findings), ENUM-SO2 1.71 (max 6, 99 rows → 169 findings). One MAIN steer carrying three credited catalog ids counts as **one** raised item; ENUM needs three, each separately at risk. A quality metric that structurally favors the terse arm cannot decide a terse-vs-verbose choice.
2. **Orderings must be robust to the credit rule, or the rule's cost must be visible.** `ITERATION1-DATA-PASS.md` §Unrecorded findings 1: **30 catalog ids matched by exactly one judge and credited to neither, 8 of them blocking, affecting 16 of 18 cells.** A union proxy moves 5 cells and breaks two published readings — the effort-dependent reversal shrinks from 5-vs-2 to 5-vs-4, and old scheduler/sol-high "ENUM 6 vs MAIN 3" becomes a **6-vs-6 tie**, which touches the "ENUM dominates, F2 is dead" narrative directly.
3. **Effect sizes must exceed n.** Same doc, verdict on surprise 5: n=1 trajectory per cell; sol-high and sol-xhigh are *different driver trajectories* (22 vs 25 points); 2 of the 5-blocker gap hinge on a single message at `r3/16`. `CONSENSUS-RESULTS.md` §Limits and `SEVERITY-V4-BLOCKING-TIER.md` §Limits say the same thing from the dataset side: 2–3 unanimous blockers means one flip moves an arm 33–50pp.
4. **Denominators must be comparable across the cells being compared.** `CAPSTONE-SCORING-RESULTS.md` §Basis: 33 of 75 active issues carry no anchors at all, so their liveness is mechanically unresolvable and they sit in every denominator of their task. `ITERATION1-DATA-PASS.md` verdict 4 measures the distribution: **scheduler 31, exporter 1, dispatcher 1** — scheduler is essentially unfiltered while exporter loses 3–4. The registered no-cross-task-summing rule (`BENCHMARK-SPEC.md` §Reading rules) contains this partially; it does not contain the per-task comparison of arms.
5. **Cost and quality must stay separate columns.** Standing rule, `BENCHMARK-SPEC.md` §Reading rules: "*quality, cost, and delivery-correctness are never fused into one number*"; msg S2-118 restates it as non-negotiable. The tradeoff is Andreas's to make, not a formula's.
6. **The lock-in table reads only the final iteration.** `BENCHMARK-SPEC.md` §Iteration protocol: "*The dataset is FINAL for lock-in comparisons only after an iteration whose data pass surfaces no dataset-label bugs (target: by iteration 3). The lock-in table reads exclusively from the final iteration; earlier passes are kept as shakedown artifacts.*" This contains one known threat: `ITERATION1-DATA-PASS.md` finding 7 (old and fresh generations judged at different builder hashes, `df3cc0f57a725965` vs `5880bf010bbb428e`, "*unmeasured residual on every fresh-vs-old sentence*") — contained **only if** no fresh-vs-old sentence survives into lock-in.

Current state against these: iteration 1 is explicitly labelled "NOT a lock-in table" (`CAPSTONE-SCORING-RESULTS.md` header), and requirements 1, 2, and 4 are open defects, not satisfied properties.

---

## 2. Integrity constraints — and where each one actually came from

### 2a. Why two judges — grounded. Why two *providers* — no recorded reasoning.

This is the single most important finding for the rethink, because it changes how much of the design space is open.

**The two-judge rule has an explicit written rationale.** `GOLDEN-DATASET-DESIGN.md` §Promotion: "*Guard: promotion requires BOTH judges. A one-judge promotion would let the set fill with unvetted opinion, and nobody could later tell which records were vetted how — hence `votes` and `promotedFrom` on the record.*" That is an argument about vetting and auditability. It says nothing about the judges being from different vendors.

**The cross-provider split has no such rationale anywhere in the record.** What the record shows instead:

- msg 109 (2026-07-26): "*Do I see correctly that you have two judges in place, one terra and one sol? I am not sure if terra as a judge is a good pick because judge quality must be strong. But I leave this up to you. Your call.*" — **the original two judges were terra and sol, both OpenAI/codex models** (terra is `gpt-5.6-terra`, per `artifacts/wave8-designs/wave8-mechanics.md`:84 "*All 559 hydra-calls are gpt-5.6-{terra,luna,sol} codex*"). So two judges predates any provider split, and the objection was **model strength**, not provider diversity.
- msg 150 (2026-07-28): "*Sol high as judge is fine. We can keep it that way.*"
- msg 163 (2026-07-28), on routing the Anthropic judge: "*We only need to route the claude judge through CC and the reason is simply because it's cheaper because it goes through the subscription instead of pay per use.*" — **cost**.
- msg S2-115/S2-118 (2026-08-02): "*The dataset must be validated by both sol and opus judges*" / "*Use both sol and opus as judges.*" — a directive naming the two, with no reason attached.

I searched both the full user-message archive and every `experiments/*.md` for independence/decorrelation/self-preference reasoning (`independen`, `decorrelat`, `correlat`, `self-preference`, `same family`, `same model`). **Nothing ties the Sol/Opus split to judge independence.** The uses of "independent" in the record all mean *round-1 independent labelling before deliberation* (`CONSENSUS-SPEC.md` §Round 1) or *independent discovery in the blind reference review* (`GOLDEN-DATASET-V2-SPEC.md`:101-105) — both are procedural independence within a protocol, not vendor independence.

**Reading:** two judges are load-bearing for a documented reason. Two *providers* is, on this record, a consequence of picking the strongest available second model after terra was rejected, plus a subscription-cost routing preference. A redesign that keeps two judges but changes their provider mix does not contradict anything Andreas wrote. A redesign that drops to one judge does.

**Adjacent, and separately settled:** the *carrier* is not load-bearing. `JUDGE-TRANSPORT-AB-SPEC.md` §Route-level correction: over 45 findings, cross-transport disagreement is at or below the same-transport repeat floor on every field (A-vs-A2 noise floor 5 / 0 / 9 / 10 discordant; A-vs-B 3 / 0 / 5 / 6; A2-vs-B 2 / 0 / 7 / 4). Verdict FLIPPABLE. Do not let "transport doesn't matter" stand in for "provider doesn't matter" — that was not tested.

### 2b. No reward hacking — Andreas's own words, repeatedly

- msg 1182 (on hard-coding a cost fix): "*I just don't agree with the hard coding suggestion. This is reward hacking that we absolutely don't want.*"
- msg 177 (`/goal`, cache work): "*Your goal is not to reward hack your way to 97%+... Your goal is it to find clean, correct and elegant solutions.*"
- msg 67: "*You are allowed to also adjust heads but just don't hardcode their behavior. No cheating.*"
- msg S3-14 quotes back approvingly: "*No further prompt tuning around known cases.*"
- The consolidated form, in the continuation brief Andreas pasted as goal msg S2-118: "*No reward hacking. Do not add answer keys, cache padding, delays, serialized heads, known-case tuning, or evaluator changes that rescue an arm.*"
- Registered in `BENCHMARK-SPEC.md` §Boundaries: "*Known-case prompt tuning remains forbidden; development variants freeze once and validate on fresh, sealed material.*"

**Provenance caveat worth carrying into the rethink:** the S2-118 "Non-negotiable constraints" list sits inside a ```text``` block Andreas pasted (lines 1632–1722 of the archive) — it is a session-continuation brief, not necessarily his own prose. Several items are independently corroborated in his own words (reward hacking msg 1182; "*I do not want to review the set. It is your and the two judges' job*" msg S2-78; the steer semantics). Others are the program's own accretions restated back to him. When grading rules as load-bearing, that distinction matters.

### 2c. No tuning toward arms — enforced by *timing*, not just by rule

The program's actual mechanism is prospective registration, and it has been exercised twice under pressure:

- `BENCHMARK-SPEC.md` §What is registered now vs later: "*The SCORING DESIGN below was registered before any judged coverage existed, so the metric cannot be tuned toward an arm after the fact.*"
- `GOLDEN-V2-PROTOCOL-DECISION.md` (via `INDEX.md`): when the precision pass terminated at 63/67 (94.0%) below the original 95% unanimity bar, the options with exact rule text were "*registered and decided while every v2 quality cell was still blank, so the choice could not be tuned toward an arm*"; the builder then ran `--adopt-decision A` and "*the projection matched the build exactly*".
- Producer/judge decoupling with the same logic (`BENCHMARK-SPEC.md`, 2026-08-02 amendment): OpenAI raw production could precede v2 "*because producer heads never see the dataset or judge labels*".

### 2d. Evaluator freeze

`BENCHMARK-SPEC.md` §Reading rules: "*no metric change after the first scored row. A metric defect found mid-run is recorded, the table finishes on the frozen metric, and the fix lands in a versioned follow-up pass.*" Applies *within* an iteration; changes land between iterations, versioned.

**Its cost is now measured and non-zero.** Iteration 1 had to publish around two known harness bugs: `render-capstone-table.mjs:19` computes absolute noise as `raised − real` while `BENCHMARK-SPEC.md`:35-38 registers both-judges-not-real — **all 18 cells differ** (`ITERATION1-DATA-PASS.md` verdict 2); and the payload liveness walker is blind on the capstone payload shape (0/131 payloads have `.messages`, 131/131 have `.input[]`), which made the entire quiet-span column vacuous (verdict 1). Both readings were published, which the data pass calls "protocol-correct" — the rule worked as designed, and it cost a whole column.

### 2e. Disagreement recorded, never averaged

`BENCHMARK-SPEC.md` §Boundaries: "*coverage follows the two-judge flow with disagreement recorded, not averaged.*" `CAPSTONE-JUDGE-SPEC.md` §Scoring boundary: "*Disagreement remains visible and is never averaged.*"

**Grounded by measurement.** `CONSENSUS-RESULTS.md` §C3, the `s01` dissent: Opus holds `blocking: false` because no code in the repo calls `renewLease`; Sol and the analyst hold `blocking: true` because it is exported public API. "*It is a real definitional split, not noise, and forcing it would have hidden the most useful thing the run found*" — the reachability convention the rubric never specified, which then became RULING 1. Four stable dissents are carried verbatim in golden v2 (`GOLDEN-DATASET-V2-RESULTS.md` §The carried dissents).

### 2f. Deliberation

`CONSENSUS-RESULTS.md` §C1: round 1 independent 9/21 (42.9%) → round 2 deliberation 19/21 (90.5%) → round 3 20/21 (95.2%) → round 4 stalled. **+52.3pp against a pre-stated 5pp "this is ceremony" bar.** §C2: 12 position changes, **8 evidence-driven, 0 authority-driven**, 4 unclassified-but-citation-based. §C4: 11 of 12 changes were the *analyst's*, not the judges' — the analyst had labelled against seeded code while the judges read the final session state.

### 2g. Two severity levels only

`SEVERITY-V4-BLOCKING-TIER.md`: exact agreement 4-level 61.9%, 3-level 66.7%, **blocking-vs-rest 90.5%, any-harm-vs-none 95.2%**; adjacent-or-better agreement was 100%, i.e. "*a scale finer than their resolution*". Consequences recorded in the same doc: authored severities not needed for scoring, pairwise ranking (SEVERITY-V3) superseded, `inDeliverable` dropped at 38.1% agreement. This is a rule that earned its narrowing by measurement.

### 2h. Judges own the labels; agents do not promote themselves

msg S2-78: "*And I do not want to review the set. It is your and the two judges' job. Please iterate until you all agree.*" msg S2-84: "*For the bonus category the judge would determine if the brand new issue is severe or not.*" Registered: `CAPSTONE-JUDGE-SPEC.md` §Scoring boundary ("*not promoted by a producer, by Sol alone, or by this runner*"), `ITERATION2-JUDGE-WAVE-SPEC.md` §Boundaries ("*a coordinator or agent never promotes on its own authority*"), `BENCHMARK-SPEC.md` §Boundaries ("*an early Sol pass fills one half of that pair, never two votes*").

### 2i. Blinding, as actually implemented

`CAPSTONE-JUDGE-SPEC.md` §Frozen questions: the judge sees the human-inspectable driver request, the exact tracked-file state, and catalog *statements only* — "*but not tiers, votes, consensus, planted labels, producing arm, delivery route, cost, or expected result*". Confirmed in `capstone-trajectory-judge-protocol.mjs:173` (prompt preamble) and `:146-150` (`activeCatalog` renders `key: statement` only). Findings within a point are ordered by `stableBlindOrder` — SHA of the hidden source key (`:157-159`).

---

## 3. Operational constraints

### 3a. Cost bases — there are three, and they are not interchangeable

| basis | what it is | where |
|---|---|---|
| harness Σ`usage.cost` | provider-reported cost against a synthetic prefix billed at **cache-write rates** — inflated, "*not production pricing, and not what Andreas was billed*" | `RUN-LEDGER.md` §Reading the frozen evidence |
| production-priced | the registered table basis: "*$/observation (production-priced)*" | `BENCHMARK-SPEC.md` §Scoring design item 5 |
| plan quota (not billed at all) | "*pi's Anthropic OAuth rides Claude-Code identity headers, so Anthropic waves consumed plan quota rather than metered API credit. Treat these as list-price equivalents.*" | `RUN-LEDGER.md` §Reading the frozen evidence |

**Judging is $0 metered.** Both judges are subscription-billed (`CONSENSUS-RESULTS.md`:7; `GOLDEN-DATASET-V1-RESULTS.md`:161; ledger rows 39/42/43 all `$0`). The binding judge resource is **wall-clock and subscription quota**, not dollars — stated as a design constraint in `artifacts/wave8-designs/wave8-benchmark.md`:105 and `wave8-quality.md`:59,80.

**Producer spend is the real money.** The registered OpenAI capstone wave: $12.9608 over 533 rows / 260 observer calls / six cells, split driver $4.995 + observer $7.9658 (frozen `summary.json`, `artifacts/2026-08-03-openai-capstone-producer`). Program total: **12,772 producer rows, 11,470 judgments, $111.61 harness basis** ($133.41 including one superseded run) — `RUN-LEDGER.md` §Program totals.

**Quota shape:** I found evidence of a resetting window ("*Anthropic resets in exactly one hour at 14:00 CEST*", msg S3-23) and quota-interruption discipline (`ITERATION2-JUDGE-WAVE-SPEC.md` §Spend and interruption discipline: "*If the weekly window dies mid-step, the recovery is the registered resume path, not improvisation*"; `STEER-ONLY-SPEC.md`:102-103). **I did not find a documented numeric weekly limit anywhere in the repo or the archive.** Treat the constraint as "a weekly window that has in fact interrupted work", not as a known number.

### 3b. The pi/Anthropic metering finding — final state, with its open caveat

`JUDGE-TRANSPORT-AB-SPEC.md` §Re-scope and first execution attempt: three pi shards refused immediately with `400 You're out of extra usage` while **Opus-via-claude-cli had judged 383 findings on the same subscription the same afternoon** (383 = 264 fresh + 119 old). The shape hypothesis was then tested directly with the real `pi` binary in production shape and **refuted** — identical refusal, request id `req_011CdhsxPHP7WqKTbV34ginD`.

§Route-level correction (same day, later) **overturns the account-level conclusion**: replaying a captured production payload directly against `/v1/messages` with the pi OAuth token returned **200 on plan quota** minutes after the binary was refused. A new `oauth-replay` transport reproduces that shape verbatim and completed 45/45 findings on plan. But: "*three capped ablations off the working shape (tools removed; interleaved-thinking beta removed; thinking swapped to enabled/budget) each still drew plan, so the field that gets a request classified out of plan coverage remains unisolated*". Untested candidates named: system-block content, message/timestamp shapes, token limits, SDK-added headers.

**Constraint for the winning design:** pi-native Opus judging is *not* currently available; only the replayed production shape is. Any design assuming pi-side Opus judging works is assuming something the record does not support.

### 3c. Reproducibility — already paid for, and it is what made the second judge column possible

- Frozen SHA-256 on rows / payloads / dataset for every judged input (`CAPSTONE-JUDGE-SPEC.md` §Second registered input: rows `7224f4e0…`, payloads `401c38df…`, dataset `4035950f…`).
- **Builder hashes pin the judge implementation**, and the record proves they are needed: the old input had to be re-judged by Opus at commit `369ed58` / builder `df3cc0f57a725965`, because "*the current working judge and working dataset are not substitutes: both have advanced since Sol answered*" (§First registered input). The fresh input ran at `5880bf010bbb428e` — the *same* builder Sol answered under.
- The frozen judge basis (`artifacts/2026-08-03-openai-capstone-judge-basis/golden-dataset.json.gz`) exists precisely so "*when the working dataset advances, Opus can still answer byte-identical questions*" (§Second-input Opus execution record).
- Runner discipline: fingerprints protocol source, rows, payloads, dataset version, catalog, rendered evidence and every prompt; atomic checkpoint after each point; resume skips completed keys, refuses drift, never overwrites another judge's file; one format-correction turn allowed and preserved (§Identity and recovery). The concurrency-3 merge is fail-closed on metadata drift, duplicates, missing findings, or counts other than the registered 107+12.
- `capstone-consensus-packet.mjs` refuses to build a packet unless rows, payloads, dataset, catalog, judge builder, finding identities **and evidence holes** are identical across the two columns, and deliberately does not align claims or decide agreement.
- Deterministic inventory: `CAPSTONE-FROZEN-INPUTS.json`; ledger with per-run provenance and gaps: `RUN-LEDGER.md`.

**This is the property that let Opus be added to Sol's column weeks later.** Any redesign that cannot replay a frozen input at a pinned builder loses the ability to add a judge column after the fact.

### 3d. Volume per iteration — measured from the artifacts

**Judge side, iteration 1 (both columns, both inputs):**

| input | findings | batches (= observation points) | judges | wall-clock measured |
|---|---:|---:|---:|---|
| fresh capstone | 264 | 109 | 2 | Opus **137.6 min** (median 76 s/batch, max 175 s, concurrency 1); Sol **95.5 min** (median 44.3 s) |
| old trajectory | 107 judged + 12 unjudgeable | 29 | 2 | Opus Σ 36.6 min across 3 shards (10.6 / 13.0 / 13.0) → ≈**13 min wall** at concurrency 3 |

Derived: **218 + 58 = 276 judge calls per iteration**, ~2.4 findings per call, ≈31 s of judge wall-clock per finding per judge. A full both-judge pass on one 264-finding input is **~3.9 h serial**, ~1.3–1.5 h with the authorized 3-way sharding. Zero dollars.

**Analyst side, iteration 1:** a **28-agent workflow** — 14 opus-high matchers (one per 27-finding batch) plus 14 opus-xhigh adversarial verifiers instructed to refute scoring-critical credits and default to refusal; 6 credits refuted, 1 skipped, 7 explicit analyst resolutions recorded in-band (`CAPSTONE-JUDGE-SPEC.md` §Cross-judge consensus execution record). Output: fresh 263 credited defects over 30 catalog issues, **143 recorded disagreements**, 34 novel candidates; old 140 credited over 16 issues, **70 disagreements**, 33 novel candidates.

**Data pass:** 3 focused opus-xhigh readers + 1 synthesizer that independently reproduced all 18 blocking-recall cells before accepting any reader claim (`ITERATION1-DATA-PASS.md` header).

**Producer side per iteration:** 6 cells × (1 driver + paired MAIN/ENUM observers) = 533 rows, 260 observer calls, $12.96.

**Iteration 2 as registered** (`ITERATION2-JUDGE-WAVE-SPEC.md` §Order of execution): 6 dataset repair records through the full three-participant protocol; one RULING-style anchor-rule confirmation plus backfill of 33 anchor-less + 12 non-portable end-state anchors; 23 fresh + 12 old cache-only re-judges (both judges); **67 novel promotion candidates in ~15-cluster batches** — named as "*the largest remaining subscription draw of the program (order of the v2 wave-2 consensus)*"; then assemble v3 and a zero-call rescore.

**Golden v2 build, for scale reference** (`GOLDEN-DATASET-V2-RESULTS.md`): 32 pool credits + 67 novel clusters + 5 rejudged records + RULING 4 and editorial confirmation passes, three participants each, up to three rounds. That wave was interrupted by quota — which is why checkpoint-per-batch is a design input rather than a nicety.

---

## 4. Load-bearing for trust vs incidental

**Load-bearing, with a measurement behind it:**

| rule | evidence it earns its keep |
|---|---|
| Two judges, both must credit | `GOLDEN-DATASET-DESIGN.md`:77 (written rationale: unvetted opinion, auditability of `votes`/`promotedFrom`) |
| Deliberation between rounds | +52.3pp (42.9→95.2%) vs a 5pp ceremony bar; 0 authority-driven changes — `CONSENSUS-RESULTS.md` C1/C2 |
| Disagreement recorded, never averaged | `s01` surfaced the reachability convention that became RULING 1 — `CONSENSUS-RESULTS.md` C3 |
| Two severity levels only | 90.5% / 95.2% vs 61.9% at four levels — `SEVERITY-V4-BLOCKING-TIER.md` |
| Blocking outranks non-blocking lexicographically | Andreas's own framing (msg S2-115) + `BENCHMARK-SPEC.md` §Reading rules; it is the product semantics, not a statistic |
| Quality / cost / delivery never fused | the decision *is* the tradeoff; msg S2-118 + `BENCHMARK-SPEC.md`:59-60 |
| Pre-registration before data | exercised under pressure twice (scoring design; `GOLDEN-V2-PROTOCOL-DECISION.md` decided with every quality cell blank) |
| Frozen inputs + pinned builder hashes | the *only* reason Opus could answer Sol's exact questions weeks later — `CAPSTONE-JUDGE-SPEC.md` §First registered input |
| Judges never promote; agents never self-promote | msg S2-78 + three registered restatements |
| Blinding of arm / route / cost / tier / planted labels | implemented and verified at `capstone-trajectory-judge-protocol.mjs:146-159,173` |

**Load-bearing but currently *costing* accuracy — i.e. the rule works and the numbers do not survive it cleanly:**

- **Intersection credit** (both judges must match the *same* catalog id). 30 one-sided matches credited to neither, 8 blocking, 16 of 18 cells; two published orderings flip under a union proxy. Plus one measured case where both judges supported the same behavior but credited different ids (`SCHED-r-d06` vs `SCHED-r-d07`), so nothing survived. `ITERATION1-DATA-PASS.md` §Unrecorded findings 1. The rule is defensible; **its cost is currently invisible in the table**, which is what makes it dangerous for lock-in.
- **Evaluator freeze.** Correct as a rule, and it forced iteration 1 to publish around two known harness bugs and lose the quiet-span column entirely (verdicts 1 and 2).

**Incidental — operational, not integrity:**

- **Concurrency 1 vs 3.** The amendment's own argument: "*Per-point judge calls are stateless with session persistence off, so verdict content is order- and concurrency-independent*" (`CAPSTONE-JUDGE-SPEC.md` §Execution-record amendment). Verified empirically — the concurrency-3 old-input pass produced an unjudgeable set "*verified identical, key by key, to the set Sol recorded*".
- **Which carrier runs Opus.** `JUDGE-TRANSPORT-AB-SPEC.md` verdict FLIPPABLE, cross-transport disagreement at or below the same-transport floor on every field.
- **Batch unit = one observation point.** Nothing integrity-wise appears to rest on it; it is what makes evidence rendering cheap. See the hazard below, though.

**Asserted, never tested — the third bucket, and the one worth naming for the rethink:**

- **The cross-provider judge split.** No recorded reasoning (§2a). Never measured as an independence property.
- **Never co-present arms in one judge prompt.** `artifacts/wave8-designs/wave8-quality.md`:59 states it as a design constraint — "*co-presentation nudges the judge toward treating X as the real one — systematically penalizing the arm that found something different*" — and preserves the earlier judge's property of drawing batch items from *different* observation points (`delivery-context-golden-judge.mjs`, fixed-size batches over independent case rows). **The capstone judge dropped that property by construction:** it batches one observation point and renders all arms' findings at that point in the same prompt. Measured from the frozen Opus checkpoint: **85 of 109 fresh-input batches co-present findings from more than one arm** (findings-per-batch histogram 1:23, 2:42, 3:25, 4:17, 7:2). Order is hash-blinded, arm identity is hidden — but the arms are still side by side. The instance the wave8 doc cites (`XHIGH-SCREEN-RESULTS.md` X2, `dev-security-user-only`) is, on inspection, a *target-metric* disagreement rather than a demonstrated co-presentation artifact, so the hazard is documented and plausible but **not directly evidenced**. It has never been tested either way.
- **Support policy calibration.** The calibrated `SUPPORT_POLICY` shipped at `delivery-context-judge-protocol.mjs:15` traces to the `2026-07-29-evaluator-calibration` run, which per `RUN-LEDGER.md` note is **judge-side only, never frozen; the analysis scripts live ONLY in the mirror**. The policy every judged number rests on has the weakest provenance of any component in the system.
- **One-sided zero-claim batches.** `ITERATION1-DATA-PASS.md` §Unrecorded findings 5: Opus returned zero claims on 17 of 109 fresh batches (27 findings, all auto-not-real); Sol did this 0 times. All well-formed model decisions, not transport damage. "*A systemic precision suppressor that hits arms unevenly by which points they steer at.*" Not re-derived by the synthesizer — reader-confidence only.

---

## 5. Requirements the winning judge design must satisfy — ranked

### MUST (a design failing any of these cannot support the lock-in decision)

1. **Produce a per-arm quality number in the same unit for every arm.** The current per-arm unit mismatch (MAIN 1.00 vs ENUM 1.71 findings per delivering row) means precision is not comparable across exactly the two arms the decision is between. `ITERATION1-DATA-PASS.md` §Unrecorded 2; lane A6 proposes normalizing the `raised` unit.
2. **Two independent judgments per finding, both required to credit, disagreement recorded verbatim and never averaged.** `GOLDEN-DATASET-DESIGN.md`:77; `BENCHMARK-SPEC.md` §Boundaries; `CONSENSUS-RESULTS.md` C3.
3. **Make the credit rule's cost visible beside every recall cell** (count of one-sided catalog matches), or adopt a credit rule whose orderings are stable. 8 blocking ids currently credited to neither judge; two orderings flip under union. `ITERATION1-DATA-PASS.md` §Unrecorded 1, lane A7.
4. **Keep quality, cost, and delivery-correctness as separate columns; blocking recall outranks any-harm lexicographically.** msg S2-115 + S2-118; `BENCHMARK-SPEC.md` §Reading rules.
5. **Score only on tiers the judges can actually resolve (blocking / any-harm).** `SEVERITY-V4-BLOCKING-TIER.md`.
6. **Register the metric and protocol before any judged cell exists; freeze the evaluator within an iteration; version changes between iterations.** `BENCHMARK-SPEC.md` §Scoring design + §Iteration protocol; `GOLDEN-V2-PROTOCOL-DECISION.md` as the worked precedent.
7. **Be replayable: frozen input hashes, a pinned builder hash, per-batch atomic checkpoints, resume that refuses drift, fail-closed merges.** This is what allowed a second judge column to be added after the fact. `CAPSTONE-JUDGE-SPEC.md` §Identity and recovery.
8. **Judges see statements only — no tiers, votes, planted labels, producing arm, delivery route, cost, or expected result.** Currently implemented; must not regress. `CAPSTONE-JUDGE-SPEC.md` §Frozen questions.
9. **No known-case tuning, no answer keys, no evaluator change that rescues an arm.** msg 1182, msg 177, msg S2-118; `BENCHMARK-SPEC.md` §Boundaries.
10. **Promotion of novel findings requires both judges plus the deliberation protocol; no agent promotes its own finding.** msg S2-78; `GOLDEN-DATASET-DESIGN.md` §Promotion; `ITERATION2-JUDGE-WAVE-SPEC.md` §Boundaries.
11. **Fit the operational envelope: judge dollars ≈ $0 (subscription), ~276 judge calls and ~2–4 h of judge wall-clock per iteration, survivable across a quota interruption via checkpoint-and-resume.** Measured §3d; `ITERATION2-JUDGE-WAVE-SPEC.md` §Spend and interruption discipline.
12. **Do not assume pi-native Opus judging.** Only the `oauth-replay` production shape is confirmed to draw plan quota; the classifying field is unisolated. `JUDGE-TRANSPORT-AB-SPEC.md` §Route-level correction.

### SHOULD (materially improves trust; a design lacking these needs a stated reason)

13. **Keep deliberation, or beat +52.3pp another way.** The 42.9%→95.2% jump is the largest measured quality effect in the judging system. `CONSENSUS-RESULTS.md` C1.
14. **Make denominators comparable across cells** — anchor backfill is named "*the single highest-leverage dataset fix for iteration 2*" (33 anchor-less records, 31 of them on one task). `CAPSTONE-SCORING-RESULTS.md` surprise 4; `ITERATION1-DATA-PASS.md` lane B1.
15. **Report effect sizes with their n and their sensitivity.** n=1 trajectory per cell, different trajectories per effort tier, single messages carrying 2 of a 5-blocker gap. `ITERATION1-DATA-PASS.md` verdict 5, lane C2.
16. **Put both generations on one eligibility policy and one prompt builder before writing any fresh-vs-old sentence** — or write none. `ITERATION1-DATA-PASS.md` finding 7 + lane A4.
17. **Make the eligibility policy arm-neutral, or report precision twice (valid-only and semantic-v2).** Cache-only-invalid incidence is unbiased per point (Fisher p=0.52) but taxes the terse arm roughly double because precision is a ratio and MAIN's denominator is 56% of ENUM's — "*structural arithmetic... will recur in every future run pairing a terse arm with a verbose one*". `ITERATION1-DATA-PASS.md` verdict 7, lane C1.
18. **Decide explicitly whether arms may be co-presented in one judge prompt.** The earlier judge separated them; the capstone judge co-presents in 85/109 batches. Whichever way it goes, it should be a decision with a reason, not an artifact of the batching unit.
19. **Give the support policy real provenance.** It is currently the least-frozen component in the chain (`RUN-LEDGER.md`, `2026-07-29-evaluator-calibration`: never frozen, scripts mirror-only).
20. **Reader-in-the-loop after each pass.** "*After each pass the analyst reads the original delivered messages, the atomic judgments, and the raw responses; summary numbers alone are insufficient*" (`CAPSTONE-JUDGE-SPEC.md` §Identity and recovery) — and msg S2-118 item 8: "*Read the raw messages and judgments after every pass.*" This is what produced every correction in §4.

### NICE (worth having, nothing breaks without it)

21. Cross-provider judge mix specifically — **no recorded requirement**; keep it if it is free, but it is not a constraint the record imposes (§2a).
22. The 2:1 weighted-recall convenience column — registered explicitly as "*for scanning the table, never for verdicts*" (`BENCHMARK-SPEC.md` §Reading rules).
23. A one-time calibration of the judges' blocking set against Andreas's own top picks — the surviving job of the retired authored-severity spec (`SEVERITY-V4-BLOCKING-TIER.md` §Consequences; `GOLD-SET-DRAFT-FOR-REVIEW.md` retired when severity was delegated).
24. Quiet-span deliveries as a column — vacuous in iteration 1 and requiring the payload-walker fix plus a corrected span derivation (minimum live-per-point is 3 in every cell, so "*no cell is one fix from a span; every cell is three*", `ITERATION1-DATA-PASS.md` verdict 1b).

---

## 6. Friction worth surfacing to the Design phase

- **The assignment's premise about two providers is not supported by the record.** The rethink should treat "two judges" and "two providers" as separable, and know that only the first has a written rationale. Getting this wrong closes design space that Andreas explicitly opened ("*I am not at all tied to those rules*").
- **The published iteration-1 orderings are less robust than the table implies**, by the data pass's own measurement — and the evaluator freeze correctly forbids fixing that inside iteration 1. Any redesign discussion that quotes iteration-1 cells as if they were verdicts is quoting a shakedown.
- **The doc's own reason for the vacuous quiet-span column is wrong** ("planted defects live from point 0" — actual minimum live-per-point is 3 in all 8 cells). Minor, but it is an example of a stated reason surviving in a spec after being disproven.
- **No numeric weekly quota exists anywhere in the record**, only evidence that the window has interrupted work twice. If a design's feasibility depends on quota headroom, that number needs measuring before it is assumed.