#!/usr/bin/env node
/**
 * Merge the three shard checkpoints of the concurrency-3 Opus pass into one
 * judge-opus.json. Fail-closed: refuses metadata drift between shards, any
 * duplicate or missing finding vs the full-input enumeration, or counts that
 * differ from the registered expectation (107 judged + 12 unjudgeable = 119).
 * Judgment objects are copied verbatim; the merged metadata restores the
 * ORIGINAL registered rows identity and records each shard's own identity.
 */
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { gunzipSync } from "node:zlib";
import { buildFindingItems } from "./impl/experiments/capstone-trajectory-judge-protocol.mjs";

const [rowsGz, out, ...shardPaths] = process.argv.slice(2);
if (!rowsGz || !out || shardPaths.length !== 3) throw new Error("usage: merge-shards.mjs <original-rows.jsonl.gz> <out.json> <shard0.json> <shard1.json> <shard2.json>");

const rows = gunzipSync(readFileSync(rowsGz)).toString().split("\n").filter(Boolean).map((line) => JSON.parse(line));
const expectedKeys = new Set(buildFindingItems(rows).map((item) => item.sourceKey));
const shards = shardPaths.map((path) => ({ path, state: JSON.parse(readFileSync(path, "utf8")) }));

const IDENTITY_KEYS = ["protocol", "judge", "judgeModel", "judgeTransport", "judgeReasoning", "judgeBuilderHash", "datasetVersion", "datasetFile", "datasetSha256", "payloadsFile", "payloadsSha256"];
const reference = shards[0].state.metadata;
for (const { path, state } of shards) {
	if (state.status !== "complete" && state.status !== "complete-with-unjudgeable") throw new Error(`${path}: status ${state.status}, refusing to merge an incomplete shard`);
	for (const key of IDENTITY_KEYS) {
		if (JSON.stringify(state.metadata[key]) !== JSON.stringify(reference[key])) throw new Error(`${path}: metadata ${key} drifts from shard 0`);
	}
	if (JSON.stringify(state.metadata.catalogHashes) !== JSON.stringify(reference.catalogHashes)) throw new Error(`${path}: catalogHashes drift`);
}

const judgments = {};
const unjudgeable = {};
for (const { path, state } of shards) {
	for (const [key, value] of Object.entries(state.judgments)) {
		if (judgments[key] || unjudgeable[key]) throw new Error(`duplicate finding ${key} in ${path}`);
		if (!expectedKeys.has(key)) throw new Error(`unexpected finding ${key} in ${path}`);
		judgments[key] = value;
	}
	for (const [key, value] of Object.entries(state.unjudgeable)) {
		if (judgments[key] || unjudgeable[key]) throw new Error(`duplicate finding ${key} in ${path}`);
		if (!expectedKeys.has(key)) throw new Error(`unexpected finding ${key} in ${path}`);
		unjudgeable[key] = value;
	}
}
const missing = [...expectedKeys].filter((key) => !judgments[key] && !unjudgeable[key]);
if (missing.length) throw new Error(`missing findings after merge: ${missing.slice(0, 5).join(", ")} (${missing.length} total)`);
if (Object.keys(judgments).length !== 107 || Object.keys(unjudgeable).length !== 12) {
	throw new Error(`counts drifted: ${Object.keys(judgments).length} judged + ${Object.keys(unjudgeable).length} unjudgeable, registered expectation is 107 + 12`);
}

const rowsBytes = readFileSync(rowsGz);
const merged = {
	metadata: {
		...reference,
		rowsFile: "rows.jsonl.gz",
		rowsSha256: createHash("sha256").update(rowsBytes).digest("hex"),
		concurrency: {
			registered: "2026-08-04 execution-record amendment: three shards by judgeable point index mod 3, pinned 369ed58 runner unmodified per shard",
			shards: shards.map(({ path, state }) => ({
				rowsFile: state.metadata.rowsFile,
				rowsSha256: state.metadata.rowsSha256,
				judged: Object.keys(state.judgments).length,
				unjudgeable: Object.keys(state.unjudgeable).length,
				batches: state.batches.length,
				failures: state.failures.length,
			})),
		},
	},
	status: "complete",
	judgments,
	unjudgeable,
	batches: shards.flatMap(({ state }) => state.batches),
	failures: shards.flatMap(({ state }) => state.failures),
	completedAt: shards.map(({ state }) => state.completedAt).sort().at(-1),
};
writeFileSync(out, `${JSON.stringify(merged, null, 1)}\n`);
console.log(`merged: ${Object.keys(judgments).length} judged + ${Object.keys(unjudgeable).length} unjudgeable across ${merged.batches.length} batches, ${merged.failures.length} failures`);
