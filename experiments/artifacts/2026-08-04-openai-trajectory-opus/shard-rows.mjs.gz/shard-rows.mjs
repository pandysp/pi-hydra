#!/usr/bin/env node
/**
 * Shard the frozen 2026-08-02-openai-trajectory rows for the concurrency-3
 * Opus pass (registered 2026-08-04). Every non-observation row (file-state,
 * driver-turn, cell markers) is kept in EVERY shard so run-end evidence
 * recovery is unchanged; only finding-producing observation rows are split,
 * by judgeable point index modulo 3 in the pinned enumeration order. The
 * pinned 369ed58 runner then runs unmodified per shard.
 */
import { readFileSync, writeFileSync } from "node:fs";
import { gunzipSync, gzipSync } from "node:zlib";
import { buildFindingItems } from "./impl/experiments/capstone-trajectory-judge-protocol.mjs";

const [rowsGz, outPrefix] = process.argv.slice(2);
if (!rowsGz || !outPrefix) throw new Error("usage: shard-rows.mjs <rows.jsonl.gz> <out-prefix>");
const lines = gunzipSync(readFileSync(rowsGz)).toString().split("\n").filter(Boolean);
const rows = lines.map((line) => JSON.parse(line));
const items = buildFindingItems(rows);
const pointOrder = [...new Set(items.map((item) => item.pointKey))];
const shardOf = new Map(pointOrder.map((key, index) => [key, index % 3]));
console.log(`${items.length} findings across ${pointOrder.length} judgeable points`);
for (const shard of [0, 1, 2]) {
	const keptLines = [];
	rows.forEach((row, index) => {
		const key = [row.runId, row.trajectoryId, row.config, row.pointId].join("/");
		// observation rows with no delivered findings are inert; keep everywhere
		const keep = row.kind !== "observation" || !shardOf.has(key) || shardOf.get(key) === shard;
		if (keep) keptLines.push(lines[index]);
	});
	writeFileSync(`${outPrefix}${shard}.jsonl.gz`, gzipSync(`${keptLines.join("\n")}\n`));
	const shardPoints = pointOrder.filter((key) => shardOf.get(key) === shard);
	console.log(`shard ${shard}: ${keptLines.length} rows, ${shardPoints.length} points, ${items.filter((item) => shardOf.get(item.pointKey) === shard).length} findings`);
}
