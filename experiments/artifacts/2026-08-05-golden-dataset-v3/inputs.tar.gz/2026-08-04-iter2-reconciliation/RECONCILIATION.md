# Iteration-2 wave checkpoint × selected dual-catalog design — reconciliation

Written 2026-08-04 by claude, per the wave spec's resume gate: "This wave may
resume only after that design's cheap verification and after its assumptions
have been reconciled explicitly with this checkpoint." This document is that
explicit reconciliation. It lives in scratch by codex's mailbox request
(2026-08-04T21:22 entry): codex integrates it into the tracked specs after its
pipeline gates are green.

Inputs: `~/scratch/2026-08-04-iter2-wave/` (full checkpoint, every consensus
file read), `experiments/ITERATION2-JUDGE-WAVE-SPEC.md` (recovery section),
`experiments/JUDGE-DESIGN-SELECTED.md`, the 21:20 snapshot of codex's
`EXPANDED-2Q-IMPLEMENTATION-SPEC.md` + `dual-catalog.mjs` + `dual-catalog-score.mjs`,
`experiments/golden-dataset.json` (v2 final, 75 active).

Codex's implementation spec already carries a six-line "Iteration-2
checkpoint" section. This document is the item-level check of those calls:
**five of its six dispositions hold; none is contradicted; several need
sharpening recorded below.**

## 1. Per-item dispositions

Checkpoint facts were re-derived from the consensus files themselves, not from
the recovery prose (they agree).

| Item | Checkpoint state (verified) | Disposition under the selected design |
|---|---|---|
| RG22 (EXP-o-xe-g22 statement re-exam) | Converged round 3: blocking:false, anyHarm:true — unanimous (all three: NaN poisons TOTAL but surfaces as the literal invalid token, visibly invalid rather than silently wrong) | **SURVIVES.** Replacement statement + tier enter the real catalog (fields: statement, severity=minor i.e. the harmful tier, provenance, trail) at the next version boundary. Unapplied so far — nothing left scratch. CORRECTION 2026-08-04T21:34: this row originally said blocking/severe; codex flagged it, the round-3 files confirm harmful, and settled-outcomes.json carried `tier:"harmful"` correctly all along. |
| RG27 (EXP-o-xe-g27 statement re-exam) | Converged round 1: blocking:true, anyHarm:true — unanimous (TOTAL trailer breaks one-line-per-order contract) | **SURVIVES.** Same mechanics as RG22 but at severity=severe; verified unanimous blocking in all three round-1 positions. |
| RG21 (EXP-o-xe-g21 statement re-exam) | Open after round 3 — genuine stable tier dissent. Final: sol non-blocking, opus blocking, analyst blocking (sol and opus literally swapped positions between rounds 1 and 2) | **SURVIVES as an Option-A termination.** The protocol that produced it defines its close: terminated at the three-round stop, enters at majority tier (severe) with sol's dissent verbatim (v2 precedent: the four carried dissents). No blinded-queue trip needed — the design's queue replaces *future* deliberation; this deliberation already ran to its registered stop. |
| AG03 (DISP-o-xd-g03 anchor repair) | Ratified round 1, unanimous true/true | **SURVIVES.** Portable anchor replaces the end-state anchor; lands in the catalog record's anchors → served to scoring as `applicability.anchors` (see §2). Metadata-only by the ratification's own terms; must not reopen the record's carried tier dissent. |
| AG17 (EXP-o-xe-g17 anchor repair) | Ratified round 1, unanimous true/true | **SURVIVES.** Same. |
| AC13 (SCHED-c-13 anchor, file-wide two-regex form) | Not ratified round 1 (both judges rejected: file-wide presence ≠ partition-in-stats) | **MOOT.** Correctly rejected; superseded by AC13B. Keep as provenance only. |
| AC13B (SCHED-c-13 anchor, stats-scoped two-sided form) | Open after round 3. Final: opus+analyst ratify; sol's remaining objection restates the file-wide concern against the already-scoped form | **REDO via the blinded human queue.** Ratification requires unanimity, so it cannot terminate by majority like a tier vote. This is exactly the queue's case: Andreas sees the scoped predicate, both rationales, and the record — and rules. (The analyst-steering worry is live here: the analyst believes sol misread the proposal; a human ruling settles it without a fourth persuasion round.) |
| RULE-ANCHOR-V2 | Adopted unanimously round 1 (amended text incorporating both judges' round-1/2 demands on the v1 attempt, which itself ended open and is MOOT/provenance) | **SURVIVES as the portable-anchor rule of record.** It is now also the routing rule for future anchor work under the new design: mechanically derivable → apply; not derivable → deliberation, which the design replaces with the blinded queue. |
| 19 ADOPTED backfill records (SCHED-r-d05/07/08/20/24/25/29/32/33/34/35/41, SCHED-o-g05, SCHED-c-08, SCHED-c-ru07a/ru13a, EXP-c-11, DISP-c-03, EXP-o-xe-g27R) | Unanimous true/true after ≤2 rounds under RULE-ANCHOR-V2 | **SURVIVES.** Anchors enter the catalog at the next version boundary. Note EXP-o-xe-g27R is the anchor for RG27's replacement statement — apply them together. |
| 3 converged-REJECTED backfill proposals (SCHED-o-g07, SCHED-o-g14, SCHED-r-d18) | Round 2 unanimous anyHarm=false: proposals unfaithful (owner-check/authorization tokens collide file-wide; the faithful site needs function-scoped matching the rule does not provide); analyst conceded them to the deliberation residue | **REDO via the blinded human queue.** Same class as the three semantic-residue records. CORRECTION discovered during byte-exact extraction: the recovery prose's "22 converged" counted convergence (agreement), not adoption — these three converged on rejecting. The consensus files are authoritative. |
| 6-record corrected residue (BF-d11/d37/d39/d44/g21R/g22R → SCHED-r-d11/d37/d39/d44, EXP-o-xe-g21R/g22R) | Corrected proposals answering the specific round-1/2 objections; Sol voted all six; Opus batch never ran (session-limit `claude exited 1`); **no consensus round exists** | **REDO — one decision needed (open question Q2).** Either complete the interrupted round under the old protocol (registered recovery path: identical inputs, only unanswered questions retried; Opus capacity exists on both sides now), or declare the round dead and send all six to the blinded queue with Sol's votes as evidence. Codex's spec preserves the Sol-only votes as incomplete old-protocol evidence — compatible with both. |
| 3 deliberation-residue records (SCHED-c-15, DISP-o-xd-g20, DISP-o-xd-g26) | Never staged for a corrected vote — the objections are SEMANTIC, not fixable mechanically: c-15's doc-limb witness ("Known gaps" caption) matches even when the table is accurate; g20/g26 proposals flip absence-of-coverage claims to state:seed, changing what the record asserts | **REDO via the blinded human queue.** RULE-ANCHOR-V2's own text routes non-derivable records to deliberation; the selected design replaces that deliberation with Andreas's blinded ruling. These three cannot be settled mechanically. |
| Six Sol-only residue votes as evidence | In `consensus-backfill-v2/judge-round1-sol.json` | **SURVIVES as incomplete old-protocol evidence** (codex's disposition, endorsed). Never mixed into new-protocol judgments regardless of how Q2 resolves. |

Anchor-less exposure after applying everything settled: 33 active records had
no anchors at v2; the 19 adopted + AG03/AG17 + (if settled) the residue and
queue items close most of that gap. Records still anchor-less at the next
freeze stay liveness-unknown and must be visibly excluded from recall
denominators, not silently counted (that was iteration-1's defect).

## 2. The mapping hypothesis — CONFIRMED

Claim tested: RULE-ANCHOR-V2 portable anchors map into the new catalog's
applicability fields.

Confirmed in the snapshot schema: `dual-catalog.mjs` `buildDualCatalogView()`
(snapshot line 166) emits for every real-catalog item
`applicability: { frame: issue.frame, anchors: issue.anchors ?? null }` — the
golden record's `anchors` field travels verbatim into the judge-facing and
scoring-facing view. And `dual-catalog-score.mjs` takes `liveRealIds` per cell
as caller-supplied input (lines 113–128): liveness is decided UPSTREAM from
anchors against the evaluated code state, exactly where the portable-anchor
rule operates. Two consequences:

- The backfill work is not old-design residue — it is load-bearing for the
  new four-bucket scoring, because severe/minor recall denominators are "live
  real ids in that cell" and liveness comes from the anchors.
- The validator tolerates `anchors` absent (`?? null`), so an anchor-less
  record passes catalog validation but can never be proven live. The scorer's
  caller must define the policy for null-anchor records (exclude-and-report,
  never guess). That policy choice belongs to codex's pipeline; flagged as Q4.

## 3. Termination of the still-open deliberations

The selected design abolishes persuasion rounds prospectively. Applied here:

- **RG21** — already terminated by the old protocol's own three-round stop:
  enters at majority tier with recorded dissent (mechanical, no queue).
- **AC13B** — blinded human queue (unanimity rule means no mechanical close).
- **SCHED-c-15, DISP-o-xd-g20, DISP-o-xd-g26** — blinded human queue
  (semantically non-derivable per the adopted rule's own routing).
- **SCHED-o-g07, SCHED-o-g14, SCHED-r-d18** — blinded human queue: their
  proposals were unanimously rejected as unfaithful in round 2 (see the
  correction in §1); the records still need anchors and the rule cannot
  produce them mechanically.
- **Six-record residue** — Q2: complete the interrupted old-protocol round OR
  route to the queue. Recommendation in Q2.

Nothing else is open: the repairs, the ratifications, and the backfill votes
(19 adopted, 3 unanimously rejected) are settled outcomes; nothing in the
checkpoint was force-converged or averaged.

## 4. Wave steps 3–6 restated under the dual-catalog world

| Old step | Registered intent | Under the selected design |
|---|---|---|
| 3. Cache-only re-judge (23 fresh findings, clarified instruction) | Versioned follow-up; iteration-1 judgments immutable | **Absorbed.** The full 2Q pass re-judges every eligible frozen finding under the new contract; a separate clarified-instruction re-run of the old contract would measure a dead instrument. Codex's "supersede" call holds. The clarified-cache-instruction QUESTION survives inside the new judge prompt, not as a separate pass. |
| 4. Old-basis re-judge (12 old cache-only findings) | Unify the basis at the current builder | **Absorbed, same reasoning.** The 12 old run-end findings stay unjudgeable (final-assistant evidence never frozen) — codex's spec already records this; they must appear in the unresolved/excluded lane, not vanish. |
| 5. Promotion of 67 novel candidates | Pool→consensus→assemble as promotion candidates | **Reshaped.** Direct promotion is MOOT: the candidates were atomized under the old claim-extraction contract the design deletes. They SURVIVE as (a) historical leads and (b) a completeness cross-check — after the new pass's catalog-growth queue settles, diff its settled novel items against the 67; anything the old extraction saw that the new pass missed is evidence about the new judge's recall, and goes to the queue, not auto-in. Codex's "historical leads" call holds; the cross-check use is the sharpening. |
| 6. Assemble v3 + rescore everything | Builder fold-in, checker green, freeze, version-bumped rescore | **Reshaped and split.** Content fold-in (RG22/RG27 statements, RG21 termination, anchors from §1) is dataset assembly — the existing golden builder machinery and Option-A mechanics. Catalog versioning, occurrence ledger, and the four-bucket rescore of all frozen arms are codex's pipeline (growth + score + reconcile). The freeze remains one boundary: both catalogs frozen before any iteration-2 score is read. |

## 5. Open questions, ranked, with recommendations

**Q1 — When do the settled step-1/2 outcomes enter the catalog?**
They change liveness and two statements, so they change the denominators the
cheap-verification sample will be read against. Recommendation: fold ALL
settled items (RG22, RG27, RG21-terminated, AG03, AG17, 19 adopted backfills)
into one real-catalog version bump BEFORE the stratified verification sample
is scored, so verification runs against the catalog iteration 2 will actually
use. Needs Andreas only as a sequencing approval; content is already settled
under the registered protocol.

**Q2 — The six-record corrected residue: complete or queue?**
Recommendation: complete the interrupted Opus batch under the old protocol id
(the registered recovery path explicitly provides for this: identical inputs,
only unanswered questions retried; it is one batch, six records). Whatever
still dissents after that round goes to the blinded queue. Rationale: the
corrected proposals each answer a specific recorded objection, so most will
likely ratify; sending all six straight to Andreas buys human time where one
cheap batch may settle five. The strict alternative (round is dead, queue
everything, zero further deliberation) is coherent with the design's
philosophy — if Andreas prefers that reading, nothing breaks. Needs Andreas.

**Q3 — AC13B and the three semantic-residue records to the blinded queue.**
Recommendation: adopt as stated in §3. The queue mechanics (opaque ids, both
rationales, no arm/model/cost) already exist in codex's reconciliation
design. Needs codex to include dataset-repair items — not just judge
disagreements — in the queue rendering; needs Andreas only to rule.

**Q4 — Null-anchor policy at scoring time.**
Records without anchors at freeze cannot prove liveness. Recommendation:
exclude from recall denominators AND report the exclusion count per cell in
the table (iteration 1's silent variant of this is what broke the
denominators). Owner: codex's scorer caller.

**Q5 — Owner and mechanics of the catalog fold-in (Q1's execution).**
The settled outcomes live in scratch consensus files. Recommendation: claude
extracts them into one machine-readable "settled checkpoint outcomes" file
(id → statement/tier/dissent/anchors + provenance pointers) for codex's
assembly to consume, so neither agent hand-transcribes the other's artifacts.
Coordination-level; no Andreas input needed unless Q1/Q2 change scope.

## Machine-readable settled outcomes (Q5, approved and executed)

`settled-outcomes.json` in this directory carries every SURVIVES-disposition
outcome for mechanical fold-in, generated by `generate-settled-outcomes.py`
(also here) which reads only the checkpoint files and `golden-dataset.json`.

Generation rule, fail-closed: an item enters the main list only when its
content is extractable byte-exactly from a checkpoint file — replacement
statements from `consensus-repairs/issues.json`, anchor proposals verbatim
from the ratification questions, backfill anchors from
`backfill-proposals.json` (the relabel-seed branch composes the vote
question's own CURRENT-anchor JSON with the voted state flip), votes from the
converging round's positions, RG21's dissent verbatim from its final round.
Anything else lands in `excluded` with the reason, never in the main list.
Blinded-queue items and the six-record residue are out of scope by design.

Result: **25 items** (2 statement replacements, 1 Option-A termination, 2
anchor repairs, 1 rule adoption, 19 adopted backfills), **3 excluded** — the
converged-rejected trio above, which the fail-closed check itself surfaced;
the §1 correction and the queue addition in §3 followed from it.

## Resume gate status

With this document, the checkpoint side of the wave-spec gate is discharged:
every checkpointed item has an explicit disposition consistent with (and in
six cases sharper than) the implementation spec's checkpoint section, and no
disposition contradicts a registered rule. The remaining half of the gate is
codex's cheap verification (DoD items in the implementation spec). Steps 3–6
stay unspent until both halves close and Andreas approves the contract.
