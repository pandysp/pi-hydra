#!/usr/bin/env python3
"""Extract every SURVIVES-disposition outcome from the iteration-2 wave
checkpoint into settled-outcomes.json. Fail-closed: anything not extractable
byte-exactly from the checkpoint files lands in "excluded" with a reason.

2026-08-05: every anchor-carrying outcome is additionally BYTE-VERIFIED
against the frozen frame sources before it may fold. Votes do not override
bytes: two unanimously adopted anchors (SCHED-r-d44's absence witness
collides file-wide with complete()'s reset; SCHED-r-d35 pins '# Scheduling'
where the seed doc says '# Scheduler') were refuted this way and route to
the blinded queue instead."""
import gzip, json, re, sys
from pathlib import Path

WAVE = Path.home() / "scratch/2026-08-04-iter2-wave"
OUT = Path.home() / "scratch/2026-08-04-iter2-reconciliation/settled-outcomes.json"
REPO = Path.home() / "dev/personal/pi-hydra.piped-discovering-minsky"
DATASET = REPO / "experiments/golden-dataset.json"
FRAME_SOURCES = json.loads(gzip.decompress(
    (REPO / "experiments/artifacts/2026-08-02-golden-dataset-v2/frame-sources.json.gz").read_bytes()))

def load(rel):
    return json.loads((WAVE / rel).read_text())

dataset = json.loads(DATASET.read_text())
by_id = {i["id"]: i for i in dataset["issues"]}

def state_files(task, state):
    t = FRAME_SOURCES["tasks"][task]
    if state == "seed":
        return t["seed"]["files"]
    if state in ("emergent", "end"):
        return t["session"]["end"]["files"]
    if state == "start":
        return t["session"]["start"]["files"]
    raise ValueError(f"unknown anchor state {state}")

def side_resolves(files, side):
    body = files.get(side["file"])
    if body is None:
        return f"{side['file']} missing from state"
    present = side.get("present")
    if present is not None:
        for rx in ([present] if isinstance(present, str) else present):
            if not re.search(rx, body):
                return f"present regex {rx!r} does not match {side['file']}"
    contradicts = side.get("contradicts")
    if contradicts is not None and not re.search(contradicts, body):
        return f"contradicts regex {contradicts!r} does not match {side['file']}"
    for token in side.get("absent", []):
        if token in body:
            return f"absent token {token!r} found in {side['file']}"
    return None

def anchor_byte_check(task, anchors):
    """RULE-ANCHOR-V2 resolution: seed state -> seed files; emergent -> session
    end. Returns None if the anchor resolves, else the refutation reason."""
    files = state_files(task, anchors["state"])
    if anchors.get("match") == "two-sided":
        for name in ("code", "doc"):
            reason = side_resolves(files, anchors[name])
            if reason:
                return f"{name} side: {reason}"
        return None
    body = files.get(anchors["file"])
    if body is None:
        return f"{anchors['file']} missing from {anchors['state']} state"
    if anchors["match"] == "literal":
        if anchors["expression"] not in body:
            return f"literal expression not found in {anchors['file']}"
    elif anchors["match"] == "regex":
        if not re.search(anchors["expression"], body):
            return f"regex expression does not match {anchors['file']}"
    else:
        return f"unknown match mode {anchors['match']}"
    for token in anchors.get("absent", []):
        if token in body:
            return f"absent token {token!r} found in {anchors['file']}"
    return None

items, excluded = [], []

def fail(item_id, kind, reason):
    excluded.append({"id": item_id, "kind": kind, "reason": reason})

# --- Statement replacements + RG21 Option-A termination (consensus-repairs) ---
rep_issues = {x["id"]: x for x in load("consensus-repairs/issues.json")["issues"]}
rep_cons = load("consensus-repairs/consensus.json")
r3 = rep_cons["rounds"]["3"]

def positions(cons_round, item_id):
    return {who: cons_round["positions"][who][item_id] for who in ("sol", "opus", "analyst")}

for rid in ("RG22", "RG27"):
    issue = rep_issues[rid]
    conv_round = "1" if rid in rep_cons["rounds"]["1"]["converged"] else "3"
    votes = positions(rep_cons["rounds"][conv_round], rid)
    tiers = {v["blocking"] for v in votes.values()}
    harms = {v["anyHarm"] for v in votes.values()}
    if len(tiers) != 1 or len(harms) != 1:
        fail(rid, "statement-replacement", f"round {conv_round} recorded as converged but positions disagree")
        continue
    items.append({
        "id": rid,
        "targetRecord": issue["replaces"],
        "kind": "statement-replacement",
        "statement": issue["statement"],
        "tier": "blocking" if votes["sol"]["blocking"] else "harmful",
        "votes": {"round": int(conv_round), "positions": votes},
        "dissent": None,
        "mechanics": "precision-pass replacement: replace statement and votes; preserve id, members, provenance, anchors, trail",
        "provenance": [
            f"{WAVE}/consensus-repairs/issues.json#issues[id={rid}].statement",
            f"{WAVE}/consensus-repairs/consensus.json#rounds.{conv_round}.positions",
        ],
    })

# RG21: terminated at the three-round stop; Option A majority tier + verbatim dissent.
rg21 = rep_issues["RG21"]
v = positions(r3, "RG21")
blocking_votes = [who for who in v if v[who]["blocking"]]
if "RG21" in r3["open"] and sorted(blocking_votes) == ["analyst", "opus"]:
    items.append({
        "id": "RG21",
        "targetRecord": rg21["replaces"],
        "kind": "option-a-termination",
        "statement": rg21["statement"],
        "tier": "blocking",
        "votes": {"round": 3, "positions": v},
        "dissent": {"by": "sol", "position": {"blocking": False, "anyHarm": True}, "verbatim": v["sol"]["reason"]},
        "mechanics": "terminated as recorded dissent at the registered three-round stop; enters at majority tier per adopted Option A; replacement statement adopted with the same precision-pass mechanics as RG22/RG27",
        "provenance": [
            f"{WAVE}/consensus-repairs/issues.json#issues[id=RG21].statement",
            f"{WAVE}/consensus-repairs/consensus.json#rounds.3.positions",
        ],
    })
else:
    fail("RG21", "option-a-termination", "final-round shape differs from the recorded 2-1 (opus+analyst blocking vs sol)")

# --- Anchor repairs AG03/AG17 (consensus-ratify, unanimous round 1) ---
# The voted proposals are JS-notation blobs inside the question text. The
# parsed forms below are hand-transcribed and PROVEN faithful: the recursive
# re-render must appear byte-exactly inside the voted question, and the
# anchor must resolve against the frozen frame sources.
AG_PARSED = {
    "AG03": {"file": "src/retry.js", "match": "regex", "state": "emergent",
             "identifier": "runAttempt",
             "expression": "(async\\s+)?function\\s+runAttempt\\b|const\\s+runAttempt\\s*=",
             "absent": ["AbortController", ".abort("]},
    "AG17": {"match": "two-sided", "state": "emergent",
             "code": {"file": "src/exporter.js",
                      "present": "SUMMARY_LABEL|\\bTOTAL\\b|summary row|trailer"},
             "doc": {"file": "docs/exports.md",
                     "contradicts": "(only|just) the header"}},
}

def render_value(v):
    if isinstance(v, dict):
        return render_blob(v)
    if isinstance(v, list):
        return "[" + ", ".join(render_value(x) for x in v) + "]"
    return json.dumps(v, ensure_ascii=False)

def render_blob(anchors):
    """Reproduce the staging fork's JS-notation render: unquoted keys,
    JSON-escaped strings, ', ' joins, recursively for nested sides."""
    return "{ " + ", ".join(f"{k}: {render_value(v)}" for k, v in anchors.items()) + " }"

rat_issues = {x["id"]: x for x in load("consensus-ratify/issues.json")["issues"]}
rat_cons = load("consensus-ratify/consensus.json")
r1 = rat_cons["rounds"]["1"]
TARGETS = {"AG03": "DISP-o-xd-g03", "AG17": "EXP-o-xe-g17"}
for rid, target in TARGETS.items():
    q = rat_issues[rid]["question"]
    marker = "PROPOSED anchor:"
    if rid not in r1["converged"]:
        fail(rid, "anchor-repair", "not in round-1 converged list")
        continue
    if marker not in q or target not in by_id:
        fail(rid, "anchor-repair", "PROPOSED anchor marker or target record missing")
        continue
    votes = positions(r1, rid)
    if not all(p["blocking"] and p["anyHarm"] for p in votes.values()):
        fail(rid, "anchor-repair", "ratification requires unanimous true/true; recorded votes differ")
        continue
    parsed = AG_PARSED[rid]
    if render_blob(parsed) not in q:
        fail(rid, "anchor-repair", "hand-transcribed anchors do not re-render byte-exactly inside the voted question")
        continue
    refuted = anchor_byte_check(by_id[target]["task"], parsed)
    if refuted:
        fail(rid, "anchor-repair", f"ratified anchor refuted by frozen frame-source bytes: {refuted}")
        continue
    items.append({
        "id": rid,
        "targetRecord": target,
        "kind": "anchor-repair",
        "anchorProposalVerbatim": q.split(marker, 1)[1].strip(),
        "anchors": parsed,
        "tier": {"unchanged": True, "current": by_id[target]["tier"]},
        "votes": {"round": 1, "positions": votes,
                  "schemaMapping": "anyHarm=faithful presence-window pin; blocking=changes no recorded outcome"},
        "dissent": None,
        "provenance": [
            f"{WAVE}/consensus-ratify/issues.json#issues[id={rid}].question(after 'PROPOSED anchor:', byte-verified by re-render)",
            f"{WAVE}/consensus-ratify/consensus.json#rounds.1.positions",
        ],
    })

# --- RULE-ANCHOR-V2 adoption ---
rule_issues = load("consensus-ruling-anchor-v2/issues.json")["issues"]
rule_cons = load("consensus-ruling-anchor-v2/consensus.json")
rq = rule_issues[0]["question"]
rv = positions(rule_cons["rounds"]["1"], "RULE-ANCHOR-V2")
if "RULE-ANCHOR-V2" in rule_cons["rounds"]["1"]["converged"] and all(
    p["blocking"] and p["anyHarm"] for p in rv.values()
):
    items.append({
        "id": "RULE-ANCHOR-V2",
        "targetRecord": None,
        "kind": "rule-adoption",
        "ruleTextVerbatim": rq,
        "tier": None,
        "votes": {"round": 1, "positions": rv},
        "dissent": None,
        "provenance": [
            f"{WAVE}/consensus-ruling-anchor-v2/issues.json#issues[0].question",
            f"{WAVE}/consensus-ruling-anchor-v2/consensus.json#rounds.1.positions",
        ],
    })
else:
    fail("RULE-ANCHOR-V2", "rule-adoption", "round-1 unanimous adoption not found as recorded")

# --- 22 converged backfill anchors ---
bf_cons = load("consensus-backfill/consensus.json")
proposals = {x["id"]: x for x in load("backfill-proposals.json")["proposals"]}
bf_questions = {x["id"]: x["question"] for x in load("consensus-backfill/issues.json")["issues"]}
r1c = set(bf_cons["rounds"]["1"]["converged"])
r2c = set(bf_cons["rounds"]["2"]["converged"])
R_SUFFIX = {"EXP-o-xe-g21R", "EXP-o-xe-g22R", "EXP-o-xe-g27R"}

def relabel_seed_anchor(rid):
    """The relabel-seed branch carries no anchors in the proposal; the vote
    question holds the CURRENT anchor as JSON plus the exact operation
    '(relabel state end->seed only)'. Extract both byte-exactly or return None."""
    q = bf_questions.get(rid, "")
    if 'PROPOSED anchor: "(relabel state end->seed only)"' not in q:
        return None
    for line in q.splitlines():
        if line.startswith("CURRENT anchor: "):
            current = json.loads(line[len("CURRENT anchor: "):])
            if current.get("state") != "end":
                return None
            return current | {"state": "seed"}
    return None

for rid in sorted(r2c):
    conv_round = "1" if rid in r1c else "2"
    proposal = proposals.get(rid)
    if proposal is None:
        fail(rid, "backfill", "no proposal in backfill-proposals.json")
        continue
    target = proposal.get("target") or (rid[:-1] if rid in R_SUFFIX else rid)
    if target not in by_id:
        fail(rid, "backfill", f"target record {target} absent from golden-dataset.json")
        continue
    votes = positions(bf_cons["rounds"][conv_round], rid)
    if not all(p["blocking"] and p["anyHarm"] for p in votes.values()):
        if all(not p["anyHarm"] for p in votes.values()):
            fail(rid, "backfill",
                 f"converged as REJECTION (round {conv_round} unanimous anyHarm=false: proposal unfaithful; "
                 "analyst conceded to the deliberation residue) — no anchor adopted; record joins the blinded-queue pool")
        else:
            fail(rid, "backfill", f"round {conv_round} listed converged but votes are neither unanimous adoption nor unanimous rejection")
        continue
    if "anchors" in proposal:
        anchors, operation = proposal["anchors"], None
        anchor_prov = f"{WAVE}/backfill-proposals.json#proposals[id={rid}].anchors"
    elif proposal["branch"] == "relabel-seed":
        anchors = relabel_seed_anchor(rid)
        operation = "relabel-state-end-to-seed"
        anchor_prov = f"{WAVE}/consensus-backfill/issues.json#issues[id={rid}].question('CURRENT anchor' JSON, state end->seed per the voted proposal)"
        if anchors is None:
            fail(rid, "backfill", "relabel-seed vote question lacks the expected CURRENT anchor JSON + relabel proposal")
            continue
    else:
        fail(rid, "backfill", f"proposal branch {proposal['branch']} carries no anchors")
        continue
    refuted = anchor_byte_check(by_id[target]["task"], anchors)
    if refuted:
        fail(rid, "backfill",
             f"adopted anchor refuted by frozen frame-source bytes: {refuted} — "
             "votes do not override bytes; record routes to the blinded human queue")
        continue
    items.append({
        "id": rid,
        "targetRecord": target,
        "kind": "backfill",
        "branch": proposal["branch"],
        "operation": operation,
        "anchors": anchors,
        "tier": {"unchanged": True, "current": by_id[target]["tier"]},
        "votes": {"round": int(conv_round), "positions": votes,
                  "schemaMapping": "anyHarm=faithful application of RULE-ANCHOR-V2; blocking=changes no recorded outcome"},
        "dissent": None,
        "provenance": [
            anchor_prov,
            f"{WAVE}/consensus-backfill/consensus.json#rounds.{conv_round}.positions",
        ],
    })

# --- Completed six-record residue (consensus-backfill-v2, round 1, 2026-08-05) ---
# Andreas's Q2 decision: the Opus half was completed under the frozen old
# protocol (prompt hash byte-identical to the checkpointed failure stub).
# The backfill-proposals.json entries for these records are STALE
# pre-correction anchors (verified: they mis-align anchors across records);
# the voted question blobs are the only authoritative source. The four
# ratified anchors are hand-transcribed below and PROVEN faithful by
# re-rendering them byte-exactly against the voted blob.
BFV2 = WAVE / "consensus-backfill-v2"
bfv2_issues = {x["id"]: x for x in json.loads((BFV2 / "issues.json").read_text())["issues"]}
bfv2_cons = json.loads((BFV2 / "consensus.json").read_text())
bfv2_r1 = bfv2_cons["rounds"]["1"]
BFV2_TARGET = {"BF-d11": "SCHED-r-d11", "BF-d37": "SCHED-r-d37", "BF-d39": "SCHED-r-d39",
               "BF-d44": "SCHED-r-d44", "BF-g21R": "EXP-o-xe-g21", "BF-g22R": "EXP-o-xe-g22"}
BFV2_ANCHORS = {
    "BF-d11": {"file": "src/worker.js", "match": "literal", "state": "seed",
               "expression": "export async function runOnce(store, worker, handler) {",
               "absent": ["renewLease("]},
    "BF-d37": {"file": "src/store.js", "match": "literal", "state": "seed",
               "expression": "store.jobs.set(job.id, { ...job });", "identifier": "saveJob"},
    "BF-d44": {"file": "src/scheduler.js", "match": "literal", "state": "seed",
               "expression": "export async function sweepExpired(store, now = Date.now()) {",
               "absent": ["leaseExpiresAt = 0", "leaseExpiresAt: 0"]},
    "BF-g22R": {"file": "src/exporter.js", "match": "regex", "state": "emergent",
                "expression": "SUMMARY_LABEL|\\bTOTAL\\b", "identifier": "trailer",
                "absent": ["Number.isFinite(", "isNaN("]},
}

def bfv2_blob(rid):
    q = bfv2_issues[rid]["question"]
    start = q.index("PROPOSED anchor: ") + len("PROPOSED anchor: ")
    end = q.find(" — ", start)
    return q[start:end if end != -1 else len(q)].strip()

def bfv2_branch(rid):
    q = bfv2_issues[rid]["question"]
    head = q.split("PROPOSED anchor:", 1)[0]
    marker = "Branch: "
    if marker not in head:
        return None
    return head.split(marker, 1)[1].split(".\n")[0].rstrip(". \n")

for rid in ("BF-d11", "BF-d37", "BF-d39", "BF-d44", "BF-g21R", "BF-g22R"):
    target = BFV2_TARGET[rid]
    if rid not in bfv2_r1["converged"]:
        votes = positions(bfv2_r1, rid)
        fail(rid, "backfill-residue",
             f"opus dissent (blocking={votes['opus']['blocking']}, anyHarm={votes['opus']['anyHarm']}) — "
             "routes to the blinded human queue per Andreas's Q2 decision, no further persuasion rounds; "
             f"voted anchor verbatim: {bfv2_blob(rid)}")
        continue
    votes = positions(bfv2_r1, rid)
    if not all(p["blocking"] and p["anyHarm"] for p in votes.values()):
        fail(rid, "backfill-residue", "listed converged but votes are not unanimous true/true")
        continue
    if target not in by_id:
        fail(rid, "backfill-residue", f"target record {target} absent from golden-dataset.json")
        continue
    anchors = BFV2_ANCHORS.get(rid)
    if anchors is None or render_blob(anchors) != bfv2_blob(rid):
        fail(rid, "backfill-residue", "hand-transcribed anchors do not re-render byte-exactly to the voted blob")
        continue
    refuted = anchor_byte_check(by_id[target]["task"], anchors)
    if refuted:
        fail(rid, "backfill-residue",
             f"ratified anchor refuted by frozen frame-source bytes: {refuted} — "
             "votes do not override bytes; record routes to the blinded human queue")
        continue
    items.append({
        "id": rid,
        "targetRecord": target,
        "kind": "backfill",
        "branch": bfv2_branch(rid),
        "operation": None,
        "anchors": anchors,
        "tier": {"unchanged": True, "current": by_id[target]["tier"]},
        "votes": {"round": 1, "positions": votes,
                  "schemaMapping": "anyHarm=faithful application of RULE-ANCHOR-V2; blocking=changes no recorded outcome"},
        "dissent": None,
        "note": ("anchors adopted for the record AFTER its settled statement replacement is applied "
                 "(RG22 for EXP-o-xe-g22); the fold applies statement replacements first")
                if rid == "BF-g22R" else None,
        "provenance": [
            f"{BFV2}/issues.json#issues[id={rid}].question(after 'PROPOSED anchor:', byte-verified by re-render)",
            f"{BFV2}/consensus.json#rounds.1.positions",
        ],
    })

out = {
    "generated": "2026-08-05 (initial 2026-08-04; regenerated after the six-record residue completed under Andreas's Q2 decision)",
    "generator": "generate-settled-outcomes.py (this directory); reads only ~/scratch/2026-08-04-iter2-wave/ + golden-dataset.json",
    "scope": "SURVIVES dispositions from RECONCILIATION.md plus the completed consensus-backfill-v2 residue, every anchor byte-verified against the frozen frame sources. Excluded by design or refuted by bytes: blinded-queue items (now ELEVEN: AC13B, SCHED-c-15, DISP-o-xd-g20, DISP-o-xd-g26, SCHED-o-g07, SCHED-o-g14, SCHED-r-d18, BF-d39, BF-g21R, BF-d44, SCHED-r-d35), MOOT items (AC13, RULE-ANCHOR v1, the 67 novel candidates).",
    "counts": {"items": len(items), "excluded": len(excluded)},
    "items": items,
    "excluded": excluded,
}
OUT.write_text(json.dumps(out, indent=1, ensure_ascii=False) + "\n")
kinds = {}
for it in items:
    kinds[it["kind"]] = kinds.get(it["kind"], 0) + 1
print(f"items={len(items)} excluded={len(excluded)} kinds={kinds}")
if excluded:
    for e in excluded:
        print("EXCLUDED:", e["id"], "-", e["reason"])
