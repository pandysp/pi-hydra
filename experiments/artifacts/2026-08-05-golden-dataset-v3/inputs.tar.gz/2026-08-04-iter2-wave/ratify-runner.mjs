#!/usr/bin/env node
/**
 * Ratification rounds for anchor-only repairs and the portable-anchor RULING.
 * Reuses the established checkpointed transports and label parser. Schema
 * mapping (documented in every prompt and in the state): anyHarm=true means
 * "the proposal is faithful/correct as put"; blocking=true means "adopting it
 * changes no recorded label, tier, or settled outcome". Unanimous true/true
 * ratifies. Any false is a recorded objection and routes to deliberation.
 */
import { existsSync, readFileSync, writeFileSync, renameSync } from "node:fs";
const REPO = "/Users/spannagel/dev/personal/pi-hydra.piped-discovering-minsky";
const { collectCheckpointedBatches } = await import(`${REPO}/experiments/golden-dataset-consensus.mjs`);
const stateDir = process.argv[2];
const round = Number.parseInt(process.argv[3] ?? "1", 10);
if (!stateDir) throw new Error("usage: ratify-runner.mjs <stateDir> [round]");

const doc = JSON.parse(readFileSync(`${stateDir}/issues.json`, "utf8"));
const analyst = JSON.parse(readFileSync(`${stateDir}/analyst-round${round}.json`, "utf8")).labels;
const ids = doc.issues.map((issue) => issue.id);
for (const id of ids) if (!analyst[id]) throw new Error(`analyst omitted ${id}`);

const prior = round > 1 ? JSON.parse(readFileSync(`${stateDir}/consensus.json`, "utf8")).rounds[round - 1] : null;
const openIds = prior ? prior.open : ids;
const items = doc.issues.filter((issue) => openIds.includes(issue.id));

const promptFor = (batch) => `${doc.preamble}

${batch.items.map((issue) => `=== ${issue.id}\n${issue.question}${prior ? `\n\nPRIOR POSITIONS (round ${round - 1}):\n${["sol", "opus", "analyst"].map((p) => `${p}: ${JSON.stringify(prior.positions[p][issue.id])}`).join("\n")}` : ""}`).join("\n\n")}

Answer as pure JSON: {"judgments":[{"id":"...","blocking":true|false,"anyHarm":true|false,"reason":"..."}]} with one entry per id, schema mapping as stated in the preamble. No other text.`;

const batches = [];
for (let i = 0; i < items.length; i += 11) batches.push({ key: `ratify-${i}`, items: items.slice(i, i + 11) });
const collect = (name) => collectCheckpointedBatches({
	name, round, stateDir, batches, promptFor,
	progress: (merged) => `  ${name}: ${Object.keys(merged).length}\n`,
	timeoutMs: 900000,
});
const sol = { ...(prior?.positions.sol ?? {}), ...(await collect("sol")) };
const opus = { ...(prior?.positions.opus ?? {}), ...(await collect("opus")) };
const positions = { sol, opus, analyst };
const agreedIds = ids.filter((id) => ["sol", "opus", "analyst"].every((p) =>
	positions[p][id].blocking === positions.sol[id].blocking && positions[p][id].anyHarm === positions.sol[id].anyHarm));
const state = existsSync(`${stateDir}/consensus.json`) ? JSON.parse(readFileSync(`${stateDir}/consensus.json`, "utf8")) : { rounds: {} };
state.rounds[round] = { positions, converged: agreedIds, open: ids.filter((id) => !agreedIds.includes(id)) };
state.ids = ids;
const tmp = `${stateDir}/consensus.json.tmp`;
writeFileSync(tmp, JSON.stringify(state, null, 1));
renameSync(tmp, `${stateDir}/consensus.json`);
console.log(`round ${round}: ${agreedIds.length}/${ids.length} ratified; open: ${state.rounds[round].open.join(",") || "none"}`);
for (const id of state.rounds[round].open) {
	for (const p of ["sol", "opus", "analyst"]) console.log(`  ${id} ${p}: ${JSON.stringify(positions[p][id]).slice(0, 260)}`);
}
